 
INSERT INTO [VENDOR] (ID, NAME) VALUES (0, 'Select Vendor');
INSERT INTO [VENDOR] (ID, NAME) VALUES (1, 'Santiago Bus Company');
INSERT INTO [VENDOR] (ID, NAME) VALUES (2, 'Sachez Guest House');
INSERT INTO [VENDOR] (ID, NAME) VALUES (3, 'San Diego Unlimited');
INSERT INTO [VENDOR] (ID, NAME) VALUES (4, 'San Pedro Hotel');
INSERT INTO [VENDOR] (ID, NAME) VALUES (5, 'San Michel Pension');
INSERT INTO [VENDOR] (ID, NAME) VALUES (6, 'Santiago Bus Company');
INSERT INTO [VENDOR] (ID, NAME) VALUES (7, 'Seine River Cruises');
INSERT INTO [VENDOR] (ID, NAME) VALUES (8, 'Sierra Horse Trekking');
INSERT INTO [VENDOR] (ID, NAME) VALUES (9, 'Silver Dollar Motel');
INSERT INTO [VENDOR] (ID, NAME) VALUES (10, 'Suva Island Tours');
INSERT INTO [VENDOR] (ID, NAME) VALUES (11, 'Taupo Treks');
INSERT INTO [VENDOR] (ID, NAME) VALUES (12, 'Tasmania Timber Tours');
INSERT INTO [VENDOR] (ID, NAME) VALUES (13, 'Terra Firma Motel');
INSERT INTO [VENDOR] (ID, NAME) VALUES (14, 'Tetris Tours');
INSERT INTO [VENDOR] (ID, NAME) VALUES (15, 'Tinseltown Holidays');
INSERT INTO [VENDOR] (ID, NAME) VALUES (16, 'Tilamo Ltd.');
INSERT INTO [VENDOR] (ID, NAME) VALUES (17, 'Toledo Bus Company');
INSERT INTO [VENDOR] (ID, NAME) VALUES (18, 'Topeka Busses and Trams');
INSERT INTO [VENDOR] (ID, NAME) VALUES (19, 'Travel Boss');
INSERT INTO [VENDOR] (ID, NAME) VALUES (20, 'Travel Bolivia');
INSERT INTO [VENDOR] (ID, NAME) VALUES (21, 'Travel Brazil');
INSERT INTO [VENDOR] (ID, NAME) VALUES (22, 'Travel Canada');
INSERT INTO [VENDOR] (ID, NAME) VALUES (23, 'Travel Delaware');
INSERT INTO [VENDOR] (ID, NAME) VALUES (24, 'Trek Uganda');
INSERT INTO [VENDOR] (ID, NAME) VALUES (25, 'Trek Brazil');
INSERT INTO [VENDOR] (ID, NAME) VALUES (26, 'Trekking Ultimo');
INSERT INTO [VENDOR] (ID, NAME) VALUES (27, 'Trips Unlimited');
INSERT INTO [VENDOR] (ID, NAME) VALUES (28, 'Trips and Treasures');
INSERT INTO [VENDOR] (ID, NAME) VALUES (29, 'Trips into the Blue');
INSERT INTO [VENDOR] (ID, NAME) VALUES (30, 'Trusty Tours');
INSERT INTO [VENDOR] (ID, NAME) VALUES (31, 'Trusty Inkeeper, The');


