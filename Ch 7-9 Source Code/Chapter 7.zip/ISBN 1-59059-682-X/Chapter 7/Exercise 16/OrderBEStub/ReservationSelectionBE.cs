using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace com.icarustravel.enterprise31.Order
{
    public class ReservationSelectionBE
    {
        ReservationSelectionDS data;

        public ReservationSelectionDS Data
        {
            get { return data; }
        }

        public static ReservationSelectionBE Get(int regionId)
        {
            ReservationSelectionBE reservationSelectionBE = new ReservationSelectionBE();
            reservationSelectionBE.data = new ReservationSelectionDS();

            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 1, "North America" }, true);
            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 2, "South America" }, true);
            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 3, "Europe" }, true);
            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 4, "Asia" }, true);
            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 4, "Africa" }, true);
            reservationSelectionBE.Data.GEOGRAPHICREGION.LoadDataRow(new object[] { 4, "Australasia" }, true);

            reservationSelectionBE.Data.RESOURCECATEGORY.LoadDataRow(new object[] { 1, "Accomodation" }, true);
            reservationSelectionBE.Data.RESOURCECATEGORY.LoadDataRow(new object[] { 2, "Tours" }, true);
            reservationSelectionBE.Data.RESOURCECATEGORY.LoadDataRow(new object[] { 3, "Travel" }, true);

            reservationSelectionBE.Data.VENDOR.LoadDataRow(new object[] { 1, "Red Vendor" }, true);
            reservationSelectionBE.Data.VENDOR.LoadDataRow(new object[] { 2, "Blue Vendor" }, true);
            reservationSelectionBE.Data.VENDOR.LoadDataRow(new object[] { 3, "Green Vendor" }, true);

            reservationSelectionBE.Data.RESOURCEOPTIONS.LoadDataRow(new object[] { "Europe", 1, "Red Vendor", 1, "Description 1", 135.0, 135.0, 1, DateTime.Now, 1, "Hotel", 1, "Single Room", 10, 3 }, true);
            reservationSelectionBE.Data.RESOURCEOPTIONS.LoadDataRow(new object[] { "Europe", 2, "Green Vendor", 2, "Description 2", 455.0, 455.0, 1, DateTime.Now, 1, "Hotel", 1, "Single Room", 10, 5 }, true);
            reservationSelectionBE.Data.RESOURCEOPTIONS.LoadDataRow(new object[] { "Europe", 3, "Purple Vendor", 3, "Description 3", 335.0, 335.0, 1, DateTime.Now, 1, "Hotel", 1, "Double Room", 5, 4 }, true);

            return reservationSelectionBE;
        }

        public DataSet GetData(int regionId)
        {
            return Get(regionId).Data;
        }

        public DataTable GetDataTable(int id, string tableName)
        {
            return Get(id).Data.Tables[tableName];
        }
    }
}
