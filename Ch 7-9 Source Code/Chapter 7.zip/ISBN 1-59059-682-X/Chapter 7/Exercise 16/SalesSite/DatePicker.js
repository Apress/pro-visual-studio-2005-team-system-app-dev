﻿// JScript File

function InitializeDatePicker( clientIDDay, clientIDMonth, clientIDYear, minDay, minMonth, minYear )
{
    var i;
    var daysInMonth;

    var dropDownDay = document.getElementById(clientIDDay);
    var dropDownMonth = document.getElementById(clientIDMonth);
    var dropDownYear = document.getElementById(clientIDYear);
           
    dropDownYear.options.length = 10;
    for(i = 0; i<dropDownYear.options.length; i++)
    {
        dropDownYear.options[i].value = i + minYear;
        dropDownYear.options[i].text = i + minYear;
    }
    dropDownYear.selectedIndex = 0;

    dropDownMonth.options.length = 13 - minMonth;
    for(i = 0; i<dropDownMonth.options.length; i++)
    {
        dropDownMonth.options[i].value = i + minMonth;
        dropDownMonth.options[i].text = i + minMonth;
    }
    dropDownMonth.selectedIndex = 0;
        
    daysInMonth = DaysInMonth(minMonth,minYear);
    
    dropDownDay.options.length = daysInMonth - minDay + 1;
    for(i = 0; i<dropDownDay.options.length; i++)
    {
        dropDownDay.options[i].value = i + minDay;
        dropDownDay.options[i].text = i + minDay;
    }   
    dropDownDay.selectedIndex = 0;
}

function FillDatePicker( clientIDDay, clientIDMonth, clientIDYear, minDay, minMonth, minYear, selectedDay, selectedMonth, selectedYear )
{
    var startDay;
    var startMonth;
    var maxMonth;
    var i;
    var daysInMonth;
    var dayOrMonthModified = false;

    var dropDownDay = document.getElementById(clientIDDay);
    var dropDownMonth = document.getElementById(clientIDMonth);
    var dropDownYear = document.getElementById(clientIDYear);   
 
    dropDownYear.options.length = 10;
    for(i = 0; i<dropDownYear.options.length; i++)
    {
        dropDownYear.options[i].value = i + minYear;
        dropDownYear.options[i].text = i + minYear;
    }
    dropDownYear.selectedIndex = selectedYear - minYear;
   
    // Set the month options to be correct for the selected year
    if(selectedYear == minYear)
    {
        dropDownMonth.options.length = 13 - minMonth;
        startMonth = minMonth;
    }
    else
    {
        dropDownMonth.options.length = 12;
        startMonth = 1;
    }
    
    for(i = 0; i<dropDownMonth.options.length; i++)
    {
        dropDownMonth.options[i].value = i + startMonth;
        dropDownMonth.options[i].text = i + startMonth;
    }
    
    dropDownMonth.selectedIndex = selectedMonth - startMonth;
        
    daysInMonth = DaysInMonth(selectedMonth,selectedYear);
    
    // Set the day options to be correct for the selected year
    if(selectedMonth == minMonth && selectedYear == minYear)
    {
        dropDownDay.options.length = daysInMonth - minDay + 1;
        startDay = minDay;
    }
    else
    {
        dropDownDay.options.length = daysInMonth;
        startDay = 1;
    }

    for(i = 0; i<dropDownDay.options.length; i++)
    {
        dropDownDay.options[i].value = i + startDay;
        dropDownDay.options[i].text = i + startDay;
    }
        
    dropDownDay.selectedIndex = selectedDay - startDay;
}

function UpdateDatePicker( clientIDDay, clientIDMonth, clientIDYear, minDay, minMonth, minYear )
{
    var selectedMonth;
    var selectedYear;
    var selectedDayIndex;
    var selectedDay;
    var startDay;
    var startMonth;
    var maxMonth;
    var i;
    var daysInMonth;
    var dayOrMonthModified = false;

    var dropDownDay = document.getElementById(clientIDDay);
    var dropDownMonth = document.getElementById(clientIDMonth);
    var dropDownYear = document.getElementById(clientIDYear);
    
    selectedMonth = parseInt(dropDownMonth.options[dropDownMonth.selectedIndex].value,10);
    selectedYear = parseInt(dropDownYear.options[dropDownYear.selectedIndex].value,10);
    selectedDay = parseInt(dropDownDay.options[dropDownDay.selectedIndex].value,10);
    
    selectedDayIndex = dropDownDay.selectedIndex;
   
    
    // Set the month options to be correct for the selected year
    if(selectedYear == minYear)
    {
        dropDownMonth.options.length = 13 - minMonth;
        startMonth = minMonth;
    }
    else
    {
        dropDownMonth.options.length = 12;
        startMonth = 1;
    }
    
    for(i = 0; i<dropDownMonth.options.length; i++)
    {
        dropDownMonth.options[i].value = i + startMonth;
        dropDownMonth.options[i].text = i + startMonth;
    }

    // Adjust the month setting to ensure that it is still in the range allowed.
    maxMonth = parseInt(dropDownMonth.options[dropDownMonth.options.length - 1].value,10);
    if(selectedMonth > maxMonth)
    {
        selectedMonth = maxMonth;
        dayOrMonthModified = true;
    }
    
    if(selectedMonth < startMonth)
    {
        selectedMonth = startMonth;
        dayOrMonthModified = true;
    }
    
    dropDownMonth.selectedIndex = selectedMonth - startMonth;
        
    daysInMonth = DaysInMonth(selectedMonth,selectedYear);
    
    // Set the day options to be correct for the selected year
    if(selectedMonth == minMonth && selectedYear == minYear)
    {
        dropDownDay.options.length = daysInMonth - minDay + 1;
        startDay = minDay;
    }
    else
    {
        dropDownDay.options.length = daysInMonth;
        startDay = 1;
    }

    for(i = 0; i<dropDownDay.options.length; i++)
    {
        dropDownDay.options[i].value = i + startDay;
        dropDownDay.options[i].text = i + startDay;
    }
    
    // Adjust the day setting to ensure that it is still in the range allowed.
    maxDay = parseInt(dropDownDay.options[dropDownDay.options.length - 1].value,10);
    if(selectedDay > maxDay)
    {
        selectedDay = maxDay;
        dayOrMonthModified = true;
    }
    
    if(selectedDay < startDay)
    {
        selectedDay = startDay;
        dayOrMonthModified = true;
    }
    
    dropDownDay.selectedIndex = selectedDay - startDay;
    
    if( dayOrMonthModified )
        window.alert("Your selected day or month has been modified\nbecause the day was invalid or because\nreservations cannot be made less than 7 days\nin advance.");

}

function IsLeapYear(year)
{
    // Leap years are divisible by four except we miss one
    // at the turn of a century, but we don't miss it if the 
    // year is divisible by 400.
    if( year % 4 == 0 && (( year % 100 !=0 ) || ( year % 400 == 0 ) ))
    {
        return true;
    }
    else
    {
        return false;
    }
}

function DaysInMonth(month,year)
{
    // 30 days hath September, April June and November,
    // All the rest have 31, excepting February alone,
    // Which hath but 28 days clear, and 29 in each leap year!
    if(month == 9 || month == 4 || month == 6 || month == 11)
    {
        return 30;
    }
    
    if(month == 2)
    {
        if(IsLeapYear(year))
        {
            return 29;
        }
        else
        {
            return 28;
        }
    }
    
    return 31;
}

