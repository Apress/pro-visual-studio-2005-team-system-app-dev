using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;



public partial class DatePicker : System.Web.UI.UserControl
{
    DateTime minimumDate = DateTime.Now + new TimeSpan(7, 0, 0, 0);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            string parameters =
                "'" + this.DropDownListDay.ClientID + "','"
                + this.DropDownListMonth.ClientID + "','"
                + this.DropDownListYear.ClientID + "',"
                + this.minimumDate.Day.ToString() + ","
                + this.minimumDate.Month.ToString() + ","
                + this.minimumDate.Year.ToString();

            this.DropDownListMonth.Attributes.Add("OnChange", "UpdateDatePicker( " + parameters + " )");
            this.DropDownListYear.Attributes.Add("OnChange", "UpdateDatePicker( " + parameters + " )");

            this.Page.ClientScript.RegisterClientScriptInclude("DatePickerJS", "DatePicker.js");
            this.Page.ClientScript.RegisterStartupScript(this.GetType(), "StartJS", "InitializeDatePicker( " + parameters + " );\n", true);

            // Initialize the drop down Items collection with the maximum number of elements  possible.  This information
            // will be overridden by the client side script, but this initialization is needed to avoid invalid arguments
            // in post pack validation.
            for (int i = 1; i <= 31; i++)
                this.DropDownListDay.Items.Add(i.ToString());
            for (int i = 1; i <= 12; i++)
                this.DropDownListMonth.Items.Add(i.ToString());
            for (int i = minimumDate.Year; i <= minimumDate.Year + 10; i++)
                this.DropDownListYear.Items.Add(i.ToString());
        }
        else
        {
            DatePicker datePicker = sender as DatePicker;

            int dayIndex = int.Parse(datePicker.DropDownListDay.SelectedValue);
            int monthIndex = int.Parse(datePicker.DropDownListMonth.SelectedValue);
            int yearIndex = int.Parse(datePicker.DropDownListYear.SelectedValue);

            string parameters =
                "'" + this.DropDownListDay.ClientID + "','"
                + this.DropDownListMonth.ClientID + "','"
                + this.DropDownListYear.ClientID + "',"
                + this.minimumDate.Day.ToString() + ","
                + this.minimumDate.Month.ToString() + ","
                + this.minimumDate.Year.ToString() + ","
                + dayIndex.ToString() + ","
                + monthIndex.ToString() + ","
                + yearIndex.ToString();

            this.DropDownListMonth.Attributes.Add("OnChange", "UpdateDatePicker( " + parameters + " )");
            this.DropDownListYear.Attributes.Add("OnChange", "UpdateDatePicker( " + parameters + " )");

            this.Page.ClientScript.RegisterClientScriptInclude("DatePickerJS", "DatePicker.js");
            this.Page.ClientScript.RegisterStartupScript(this.GetType(), "StartJS", "FillDatePicker( " + parameters + " );\n", true);
        }
    }
}

