Public Class VendorBE
    Public data As VendorDS

    Public Shared Function [Get](ByVal id As Integer) As VendorBE

        Dim vendorFields As Object() = {1, "Company1", "Contact1", _
           1, "Bus Address Line 1", "Bus Address Line 2", 1, "BusCity1", 1, 1, "BusRegion1", "12345", _
           1, "Mail Address Line 1", "Mail Address Line 2", 1, "MailCity1", 2, 2, "MailRegion1", "54321", _
           1, "12", "123", "1234", _
           1, "12", "123", "1234", _
           1, "12", "123", "1234", _
           "mail@mail.com"}

        Dim vendorBE As VendorBE

        vendorBE = New VendorBE
        vendorBE.data = New VendorDS

        vendorBE.data.VENDOR.LoadDataRow(vendorFields, True)

        Dim stateFields1 As Object() = {1, "Arkansas", "AK"}
        Dim stateFields2 As Object() = {2, "California", "CA"}
        Dim stateFields3 As Object() = {3, "Washington", "WA"}

        vendorBE.data.STATE.LoadDataRow(stateFields1, True)
        vendorBE.data.STATE.LoadDataRow(stateFields2, True)
        vendorBE.data.STATE.LoadDataRow(stateFields3, True)

        Dim countryFields1 As Object() = {1, "Australia", "", "", ""}
        Dim countryFields2 As Object() = {2, "Canada", "", "", ""}
        Dim countryFields3 As Object() = {3, "Zambia", "", "", ""}

        vendorBE.data.COUNTRY.LoadDataRow(countryFields1, True)
        vendorBE.data.COUNTRY.LoadDataRow(countryFields2, True)
        vendorBE.data.COUNTRY.LoadDataRow(countryFields3, True)

        Dim resourceFields1 As Object() = {1, "Resource 1"}
        Dim resourceFields2 As Object() = {2, "Resource 2"}

        vendorBE.data.RESOURCE.LoadDataRow(resourceFields1, True)
        vendorBE.data.RESOURCE.LoadDataRow(resourceFields2, True)

        Return vendorBE

    End Function

End Class
