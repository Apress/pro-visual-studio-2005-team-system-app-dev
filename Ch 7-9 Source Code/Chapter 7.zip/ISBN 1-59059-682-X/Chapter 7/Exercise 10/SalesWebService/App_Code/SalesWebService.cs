using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using com.icarustravel.enterprise31.Customer;

namespace com.icarustravel.enterprise31.SalesWebService
{
    [System.Web.Services.WebServiceBinding(Name = "SalesWebService", ConformsTo = System.Web.Services.WsiProfiles.BasicProfile1_1, EmitConformanceClaims = true, Namespace = "http://webservices.enterprise31.icarustravel.com"), System.Web.Services.Protocols.SoapDocumentService(), System.Web.Services.WebService(Namespace = "http://webservices.enterprise31.icarustravel.com")]
    public class SalesWebService : System.Web.Services.WebService
    {
        [System.Web.Services.WebMethod()]
        public CustomerDS GetCustomer(int id)
        {
            return CustomerBE.Get(id).Data;
        }

        [System.Web.Services.WebMethod()]
        public CustomerSearchDS GetCustomerBySearch(string id,
                                                        string familyName, string givenName)
        {
            return CustomerSearchBE.Get(id, familyName, givenName).Data;
        }
    }
}
