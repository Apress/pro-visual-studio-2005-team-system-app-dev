using System;
using System.Collections.Generic;
using System.Text;

namespace com.icarustravel.enterprise31.BusinessEntity
{
    public class DualPersistBE
    {
        public enum InstallMode
        {
            SERVER = 0,
            CLIENT = 1
        }

        private static InstallMode installedMode = InstallMode.SERVER;

        public static InstallMode InstalledMode
        {
            get { return installedMode; }
            set { installedMode = value; }
        }
    }
}

