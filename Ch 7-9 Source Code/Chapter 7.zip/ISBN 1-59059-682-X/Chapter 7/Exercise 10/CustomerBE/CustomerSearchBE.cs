using System;
using System.Collections.Generic;
using System.Text;

using com.icarustravel.enterprise31.BusinessEntity;
using com.icarustravel.enterprise31.Customer.CustomerSearchDSTableAdapters;

namespace com.icarustravel.enterprise31.Customer
{
    public class CustomerSearchBE
        : BusinessEntityBE<CustomerSearchDS, SalesWS.CustomerSearchDS>
    {
        protected override SalesWS.CustomerSearchDS GetRemoteData(
                                                 object[] searchStrings)
        {
            SalesWS.SalesWebService salesWebService = new SalesWS.SalesWebService();
            if (wSURL != null)
            {
                salesWebService.Url = wSURL;
            }

            return salesWebService.GetCustomerBySearch((string)searchStrings[0],
              (string)searchStrings[1], (string)searchStrings[2]);
        }

        protected override void GetLocalData(object[] searchStrings)
        {
            new CUSTOMERSEARCHTableAdapter().Fill(
                      data.CUSTOMERSEARCH, (string)searchStrings[0],
                      (string)searchStrings[1], (string)searchStrings[2]);
        }

        public static CustomerSearchBE Get(string id,
                         string familyName, string givenName)
        {
            CustomerSearchBE customerSearchBE = new CustomerSearchBE();
            customerSearchBE.Fill(new string[] { id, familyName, givenName });
            return customerSearchBE;
        }
    }
}

