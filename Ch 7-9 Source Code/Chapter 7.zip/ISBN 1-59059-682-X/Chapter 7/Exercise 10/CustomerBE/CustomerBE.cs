using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using com.icarustravel.enterprise31.BusinessEntity;
using com.icarustravel.enterprise31.Customer.CustomerDSTableAdapters;

namespace com.icarustravel.enterprise31.Customer
{
    public class CustomerBE : BusinessEntityBE<CustomerDS, SalesWS.CustomerDS>
    {
        private CustomerBE()
            : base()
        {
        }

        protected override SalesWS.CustomerDS GetRemoteData(int id)
        {
            SalesWS.SalesWebService salesWebService = new SalesWS.SalesWebService();
            if (wSURL != null)
            {
                salesWebService.Url = wSURL;
            }

            return salesWebService.GetCustomer(id);
        }

        protected override void GetLocalData(int id)
        {
            new COUNTRIESTableAdapter().Fill(data.COUNTRIES);
            new STATESTableAdapter().Fill(data.STATES);
            new ORDERTableAdapter().Fill(data.ORDER, id);
            new CUSTOMERTableAdapter().Fill(data.CUSTOMER, id);
        }

        public static CustomerBE Get(int id)
        {
            CustomerBE customerBE = new CustomerBE();
            customerBE.Fill(id);
            return customerBE;
        }

        public static DataTable GetData(int id, string tableName)
        {
            return Get(id).data.Tables[tableName];
        }
    }
}


