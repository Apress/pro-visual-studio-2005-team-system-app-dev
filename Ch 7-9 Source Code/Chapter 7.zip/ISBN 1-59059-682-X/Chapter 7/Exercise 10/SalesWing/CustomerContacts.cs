using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace com.icarustravel.enterprise31.SalesWing
{
    public partial class CustomerContacts : Form
    {
        public CustomerContacts()
        {
            InitializeComponent();
        }

        private void openCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create a CustomerDetails User Composite Control
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.Dock = DockStyle.Fill;     // Dock style to fill all of tab page

            // Create a new Tab Page, place the new customer details control in it
            // and add it to the TabPages collection of the customers tab control.
            TabPage newTabPage = new TabPage();
            newTabPage.Text = "Customer Name";          // Tempory name for test
            newTabPage.Controls.Add(customerDetails);
            this.tabControlCustomers.TabPages.Add(newTabPage);
        }
    }
}