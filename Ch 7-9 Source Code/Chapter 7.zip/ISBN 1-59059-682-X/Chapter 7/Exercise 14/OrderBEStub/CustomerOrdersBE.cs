using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace com.icarustravel.enterprise31.Order
{
    public class CustomerOrdersBE
    {
        CustomerOrdersDS data;

        public CustomerOrdersDS Data
        {
            get { return data; }
        }

        public static CustomerOrdersBE Get(int id)
        {
            CustomerOrdersBE customerOrdersBE = new CustomerOrdersBE();
            customerOrdersBE.data = new CustomerOrdersDS();

            customerOrdersBE.Data.ORDER.LoadDataRow(new object[] { 1, DateTime.Now },
                true);
            customerOrdersBE.Data.ORDER.LoadDataRow(new object[] { 2, DateTime.Now },
                true);
            customerOrdersBE.Data.ORDER.LoadDataRow(new object[] { 3, DateTime.Now },
                true);
            customerOrdersBE.Data.ORDER.LoadDataRow(new object[] { 4, DateTime.Now },
                true);

            return customerOrdersBE;
        }

        public DataTable GetDataTable(int id, string tableName)
        {
            return Get(id).Data.Tables[tableName];
        }
    }
}
