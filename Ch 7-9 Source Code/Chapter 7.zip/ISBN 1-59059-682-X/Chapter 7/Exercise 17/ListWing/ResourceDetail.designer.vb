<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ResourceDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelName = New System.Windows.Forms.Label
        Me.LabelDescription = New System.Windows.Forms.Label
        Me.TextBoxName = New System.Windows.Forms.TextBox
        Me.TextBoxDescription = New System.Windows.Forms.TextBox
        Me.LabelVendorID = New System.Windows.Forms.Label
        Me.LabelVendorIDValue = New System.Windows.Forms.Label
        Me.LabelVendorNameValue = New System.Windows.Forms.Label
        Me.LabelVendorName = New System.Windows.Forms.Label
        Me.LabelResourceID = New System.Windows.Forms.Label
        Me.LabelResourceIDValue = New System.Windows.Forms.Label
        Me.ComboBoxResourceCategory = New System.Windows.Forms.ComboBox
        Me.ComboBoxGeographicRegion = New System.Windows.Forms.ComboBox
        Me.ButtonOK = New System.Windows.Forms.Button
        Me.ButtonCancel = New System.Windows.Forms.Button
        Me.LabelResourceLocation = New System.Windows.Forms.Label
        Me.LabelResourceCategory = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.General = New System.Windows.Forms.TabPage
        Me.Availability = New System.Windows.Forms.TabPage
        Me.LabelAvailabilityPeriods = New System.Windows.Forms.Label
        Me.ButtonDeleteAvailabilityPeriod = New System.Windows.Forms.Button
        Me.ButtonAddAvailabilityPeriod = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.DateTimePickerPeriodStartDate = New System.Windows.Forms.DateTimePicker
        Me.DateTimePickerPeriodEndDate = New System.Windows.Forms.DateTimePicker
        Me.LabelCapacity = New System.Windows.Forms.Label
        Me.LabelPeriodStartDate = New System.Windows.Forms.Label
        Me.MaskedTextBoxCapacity = New System.Windows.Forms.MaskedTextBox
        Me.LabelPeriodEndDate = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.STARTDATEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ENDDATEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.CAPACITYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TabControl1.SuspendLayout()
        Me.General.SuspendLayout()
        Me.Availability.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelName
        '
        Me.LabelName.AutoSize = True
        Me.LabelName.Location = New System.Drawing.Point(8, 13)
        Me.LabelName.Name = "LabelName"
        Me.LabelName.Size = New System.Drawing.Size(35, 13)
        Me.LabelName.TabIndex = 0
        Me.LabelName.Text = "Name"
        '
        'LabelDescription
        '
        Me.LabelDescription.AutoSize = True
        Me.LabelDescription.Location = New System.Drawing.Point(10, 38)
        Me.LabelDescription.Name = "LabelDescription"
        Me.LabelDescription.Size = New System.Drawing.Size(60, 13)
        Me.LabelDescription.TabIndex = 1
        Me.LabelDescription.Text = "Description"
        '
        'TextBoxName
        '
        Me.TextBoxName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxName.Location = New System.Drawing.Point(120, 10)
        Me.TextBoxName.Name = "TextBoxName"
        Me.TextBoxName.Size = New System.Drawing.Size(356, 20)
        Me.TextBoxName.TabIndex = 2
        '
        'TextBoxDescription
        '
        Me.TextBoxDescription.AcceptsReturn = True
        Me.TextBoxDescription.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxDescription.Location = New System.Drawing.Point(120, 35)
        Me.TextBoxDescription.Multiline = True
        Me.TextBoxDescription.Name = "TextBoxDescription"
        Me.TextBoxDescription.Size = New System.Drawing.Size(356, 160)
        Me.TextBoxDescription.TabIndex = 3
        '
        'LabelVendorID
        '
        Me.LabelVendorID.AutoSize = True
        Me.LabelVendorID.Location = New System.Drawing.Point(7, 9)
        Me.LabelVendorID.Name = "LabelVendorID"
        Me.LabelVendorID.Size = New System.Drawing.Size(55, 13)
        Me.LabelVendorID.TabIndex = 4
        Me.LabelVendorID.Text = "Vendor ID"
        '
        'LabelVendorIDValue
        '
        Me.LabelVendorIDValue.AutoSize = True
        Me.LabelVendorIDValue.Location = New System.Drawing.Point(86, 9)
        Me.LabelVendorIDValue.Name = "LabelVendorIDValue"
        Me.LabelVendorIDValue.Size = New System.Drawing.Size(0, 13)
        Me.LabelVendorIDValue.TabIndex = 5
        '
        'LabelVendorNameValue
        '
        Me.LabelVendorNameValue.AutoSize = True
        Me.LabelVendorNameValue.Location = New System.Drawing.Point(236, 9)
        Me.LabelVendorNameValue.Name = "LabelVendorNameValue"
        Me.LabelVendorNameValue.Size = New System.Drawing.Size(0, 13)
        Me.LabelVendorNameValue.TabIndex = 7
        '
        'LabelVendorName
        '
        Me.LabelVendorName.AutoSize = True
        Me.LabelVendorName.Location = New System.Drawing.Point(150, 9)
        Me.LabelVendorName.Name = "LabelVendorName"
        Me.LabelVendorName.Size = New System.Drawing.Size(72, 13)
        Me.LabelVendorName.TabIndex = 6
        Me.LabelVendorName.Text = "Vendor Name"
        '
        'LabelResourceID
        '
        Me.LabelResourceID.AutoSize = True
        Me.LabelResourceID.Location = New System.Drawing.Point(7, 31)
        Me.LabelResourceID.Name = "LabelResourceID"
        Me.LabelResourceID.Size = New System.Drawing.Size(67, 13)
        Me.LabelResourceID.TabIndex = 8
        Me.LabelResourceID.Text = "Resource ID"
        '
        'LabelResourceIDValue
        '
        Me.LabelResourceIDValue.AutoSize = True
        Me.LabelResourceIDValue.Location = New System.Drawing.Point(86, 31)
        Me.LabelResourceIDValue.Name = "LabelResourceIDValue"
        Me.LabelResourceIDValue.Size = New System.Drawing.Size(0, 13)
        Me.LabelResourceIDValue.TabIndex = 9
        '
        'ComboBoxResourceCategory
        '
        Me.ComboBoxResourceCategory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBoxResourceCategory.DisplayMember = "LOCATION.NAME"
        Me.ComboBoxResourceCategory.FormattingEnabled = True
        Me.ComboBoxResourceCategory.Location = New System.Drawing.Point(120, 204)
        Me.ComboBoxResourceCategory.Name = "ComboBoxResourceCategory"
        Me.ComboBoxResourceCategory.Size = New System.Drawing.Size(356, 21)
        Me.ComboBoxResourceCategory.TabIndex = 10
        Me.ComboBoxResourceCategory.ValueMember = "LOCATION.ID"
        '
        'ComboBoxGeographicRegion
        '
        Me.ComboBoxGeographicRegion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBoxGeographicRegion.DisplayMember = "CATEGORY.NAME"
        Me.ComboBoxGeographicRegion.FormattingEnabled = True
        Me.ComboBoxGeographicRegion.Location = New System.Drawing.Point(120, 234)
        Me.ComboBoxGeographicRegion.Name = "ComboBoxGeographicRegion"
        Me.ComboBoxGeographicRegion.Size = New System.Drawing.Size(356, 21)
        Me.ComboBoxGeographicRegion.TabIndex = 11
        Me.ComboBoxGeographicRegion.ValueMember = "CATEGORY.ID"
        '
        'ButtonOK
        '
        Me.ButtonOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ButtonOK.Location = New System.Drawing.Point(398, 394)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.Size = New System.Drawing.Size(75, 23)
        Me.ButtonOK.TabIndex = 12
        Me.ButtonOK.Text = "OK"
        Me.ButtonOK.UseVisualStyleBackColor = True
        '
        'ButtonCancel
        '
        Me.ButtonCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonCancel.Location = New System.Drawing.Point(317, 394)
        Me.ButtonCancel.Name = "ButtonCancel"
        Me.ButtonCancel.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCancel.TabIndex = 13
        Me.ButtonCancel.Text = "Cancel"
        Me.ButtonCancel.UseVisualStyleBackColor = True
        '
        'LabelResourceLocation
        '
        Me.LabelResourceLocation.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelResourceLocation.AutoSize = True
        Me.LabelResourceLocation.Location = New System.Drawing.Point(10, 207)
        Me.LabelResourceLocation.Name = "LabelResourceLocation"
        Me.LabelResourceLocation.Size = New System.Drawing.Size(97, 13)
        Me.LabelResourceLocation.TabIndex = 14
        Me.LabelResourceLocation.Text = "Resource Location"
        '
        'LabelResourceCategory
        '
        Me.LabelResourceCategory.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelResourceCategory.AutoSize = True
        Me.LabelResourceCategory.Location = New System.Drawing.Point(10, 237)
        Me.LabelResourceCategory.Name = "LabelResourceCategory"
        Me.LabelResourceCategory.Size = New System.Drawing.Size(98, 13)
        Me.LabelResourceCategory.TabIndex = 15
        Me.LabelResourceCategory.Text = "Resource Category"
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.General)
        Me.TabControl1.Controls.Add(Me.Availability)
        Me.TabControl1.Location = New System.Drawing.Point(1, 59)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(493, 333)
        Me.TabControl1.TabIndex = 16
        '
        'General
        '
        Me.General.Controls.Add(Me.TextBoxDescription)
        Me.General.Controls.Add(Me.LabelResourceCategory)
        Me.General.Controls.Add(Me.LabelName)
        Me.General.Controls.Add(Me.LabelResourceLocation)
        Me.General.Controls.Add(Me.LabelDescription)
        Me.General.Controls.Add(Me.TextBoxName)
        Me.General.Controls.Add(Me.ComboBoxResourceCategory)
        Me.General.Controls.Add(Me.ComboBoxGeographicRegion)
        Me.General.Location = New System.Drawing.Point(4, 4)
        Me.General.Name = "General"
        Me.General.Padding = New System.Windows.Forms.Padding(3)
        Me.General.Size = New System.Drawing.Size(485, 307)
        Me.General.TabIndex = 0
        Me.General.Text = "General"
        Me.General.UseVisualStyleBackColor = True
        '
        'Availability
        '
        Me.Availability.Controls.Add(Me.LabelAvailabilityPeriods)
        Me.Availability.Controls.Add(Me.ButtonDeleteAvailabilityPeriod)
        Me.Availability.Controls.Add(Me.ButtonAddAvailabilityPeriod)
        Me.Availability.Controls.Add(Me.GroupBox1)
        Me.Availability.Controls.Add(Me.DataGridView1)
        Me.Availability.Location = New System.Drawing.Point(4, 4)
        Me.Availability.Name = "Availability"
        Me.Availability.Padding = New System.Windows.Forms.Padding(3)
        Me.Availability.Size = New System.Drawing.Size(485, 307)
        Me.Availability.TabIndex = 1
        Me.Availability.Text = "Availability"
        Me.Availability.UseVisualStyleBackColor = True
        '
        'LabelAvailabilityPeriods
        '
        Me.LabelAvailabilityPeriods.AutoSize = True
        Me.LabelAvailabilityPeriods.Location = New System.Drawing.Point(7, 7)
        Me.LabelAvailabilityPeriods.Name = "LabelAvailabilityPeriods"
        Me.LabelAvailabilityPeriods.Size = New System.Drawing.Size(94, 13)
        Me.LabelAvailabilityPeriods.TabIndex = 12
        Me.LabelAvailabilityPeriods.Text = "Availability Periods"
        '
        'ButtonDeleteAvailabilityPeriod
        '
        Me.ButtonDeleteAvailabilityPeriod.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonDeleteAvailabilityPeriod.Location = New System.Drawing.Point(196, 159)
        Me.ButtonDeleteAvailabilityPeriod.Name = "ButtonDeleteAvailabilityPeriod"
        Me.ButtonDeleteAvailabilityPeriod.Size = New System.Drawing.Size(135, 23)
        Me.ButtonDeleteAvailabilityPeriod.TabIndex = 11
        Me.ButtonDeleteAvailabilityPeriod.Text = "Delete Availability Period"
        Me.ButtonDeleteAvailabilityPeriod.UseVisualStyleBackColor = True
        '
        'ButtonAddAvailabilityPeriod
        '
        Me.ButtonAddAvailabilityPeriod.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonAddAvailabilityPeriod.Location = New System.Drawing.Point(337, 159)
        Me.ButtonAddAvailabilityPeriod.Name = "ButtonAddAvailabilityPeriod"
        Me.ButtonAddAvailabilityPeriod.Size = New System.Drawing.Size(131, 23)
        Me.ButtonAddAvailabilityPeriod.TabIndex = 10
        Me.ButtonAddAvailabilityPeriod.Text = "Add Availability Period"
        Me.ButtonAddAvailabilityPeriod.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DateTimePickerPeriodStartDate)
        Me.GroupBox1.Controls.Add(Me.DateTimePickerPeriodEndDate)
        Me.GroupBox1.Controls.Add(Me.LabelCapacity)
        Me.GroupBox1.Controls.Add(Me.LabelPeriodStartDate)
        Me.GroupBox1.Controls.Add(Me.MaskedTextBoxCapacity)
        Me.GroupBox1.Controls.Add(Me.LabelPeriodEndDate)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 188)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(452, 110)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "New Availability Entry"
        '
        'DateTimePickerPeriodStartDate
        '
        Me.DateTimePickerPeriodStartDate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateTimePickerPeriodStartDate.Location = New System.Drawing.Point(140, 21)
        Me.DateTimePickerPeriodStartDate.Name = "DateTimePickerPeriodStartDate"
        Me.DateTimePickerPeriodStartDate.Size = New System.Drawing.Size(301, 20)
        Me.DateTimePickerPeriodStartDate.TabIndex = 2
        '
        'DateTimePickerPeriodEndDate
        '
        Me.DateTimePickerPeriodEndDate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateTimePickerPeriodEndDate.Location = New System.Drawing.Point(140, 48)
        Me.DateTimePickerPeriodEndDate.Name = "DateTimePickerPeriodEndDate"
        Me.DateTimePickerPeriodEndDate.Size = New System.Drawing.Size(301, 20)
        Me.DateTimePickerPeriodEndDate.TabIndex = 3
        '
        'LabelCapacity
        '
        Me.LabelCapacity.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelCapacity.AutoSize = True
        Me.LabelCapacity.Location = New System.Drawing.Point(13, 78)
        Me.LabelCapacity.Name = "LabelCapacity"
        Me.LabelCapacity.Size = New System.Drawing.Size(48, 13)
        Me.LabelCapacity.TabIndex = 8
        Me.LabelCapacity.Text = "Capacity"
        '
        'LabelPeriodStartDate
        '
        Me.LabelPeriodStartDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelPeriodStartDate.AutoSize = True
        Me.LabelPeriodStartDate.Location = New System.Drawing.Point(13, 25)
        Me.LabelPeriodStartDate.Name = "LabelPeriodStartDate"
        Me.LabelPeriodStartDate.Size = New System.Drawing.Size(55, 13)
        Me.LabelPeriodStartDate.TabIndex = 5
        Me.LabelPeriodStartDate.Text = "Start Date"
        '
        'MaskedTextBoxCapacity
        '
        Me.MaskedTextBoxCapacity.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaskedTextBoxCapacity.Location = New System.Drawing.Point(140, 75)
        Me.MaskedTextBoxCapacity.Mask = "000"
        Me.MaskedTextBoxCapacity.Name = "MaskedTextBoxCapacity"
        Me.MaskedTextBoxCapacity.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.MaskedTextBoxCapacity.Size = New System.Drawing.Size(61, 20)
        Me.MaskedTextBoxCapacity.TabIndex = 7
        Me.MaskedTextBoxCapacity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabelPeriodEndDate
        '
        Me.LabelPeriodEndDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelPeriodEndDate.AutoSize = True
        Me.LabelPeriodEndDate.Location = New System.Drawing.Point(13, 52)
        Me.LabelPeriodEndDate.Name = "LabelPeriodEndDate"
        Me.LabelPeriodEndDate.Size = New System.Drawing.Size(52, 13)
        Me.LabelPeriodEndDate.TabIndex = 6
        Me.LabelPeriodEndDate.Text = "End Date"
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.STARTDATEDataGridViewTextBoxColumn, Me.ENDDATEDataGridViewTextBoxColumn, Me.CAPACITYDataGridViewTextBoxColumn})
        Me.DataGridView1.DataMember = "RESOURCEAVAILABILITY"
        Me.DataGridView1.Location = New System.Drawing.Point(3, 25)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(479, 119)
        Me.DataGridView1.TabIndex = 0
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'STARTDATEDataGridViewTextBoxColumn
        '
        Me.STARTDATEDataGridViewTextBoxColumn.DataPropertyName = "STARTDATE"
        Me.STARTDATEDataGridViewTextBoxColumn.HeaderText = "STARTDATE"
        Me.STARTDATEDataGridViewTextBoxColumn.Name = "STARTDATEDataGridViewTextBoxColumn"
        '
        'ENDDATEDataGridViewTextBoxColumn
        '
        Me.ENDDATEDataGridViewTextBoxColumn.DataPropertyName = "ENDDATE"
        Me.ENDDATEDataGridViewTextBoxColumn.HeaderText = "ENDDATE"
        Me.ENDDATEDataGridViewTextBoxColumn.Name = "ENDDATEDataGridViewTextBoxColumn"
        '
        'CAPACITYDataGridViewTextBoxColumn
        '
        Me.CAPACITYDataGridViewTextBoxColumn.DataPropertyName = "CAPACITY"
        Me.CAPACITYDataGridViewTextBoxColumn.HeaderText = "CAPACITY"
        Me.CAPACITYDataGridViewTextBoxColumn.Name = "CAPACITYDataGridViewTextBoxColumn"
        '
        'ResourceDetail
        '
        Me.AcceptButton = Me.ButtonOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ButtonCancel
        Me.ClientSize = New System.Drawing.Size(492, 423)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ButtonCancel)
        Me.Controls.Add(Me.ButtonOK)
        Me.Controls.Add(Me.LabelResourceIDValue)
        Me.Controls.Add(Me.LabelResourceID)
        Me.Controls.Add(Me.LabelVendorNameValue)
        Me.Controls.Add(Me.LabelVendorName)
        Me.Controls.Add(Me.LabelVendorIDValue)
        Me.Controls.Add(Me.LabelVendorID)
        Me.Name = "ResourceDetail"
        Me.Text = "Resource Detail"
        Me.TabControl1.ResumeLayout(False)
        Me.General.ResumeLayout(False)
        Me.General.PerformLayout()
        Me.Availability.ResumeLayout(False)
        Me.Availability.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelName As System.Windows.Forms.Label
    Friend WithEvents LabelDescription As System.Windows.Forms.Label
    Friend WithEvents TextBoxName As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxDescription As System.Windows.Forms.TextBox
    Friend WithEvents LabelVendorID As System.Windows.Forms.Label
    Friend WithEvents LabelVendorIDValue As System.Windows.Forms.Label
    Friend WithEvents LabelVendorNameValue As System.Windows.Forms.Label
    Friend WithEvents LabelVendorName As System.Windows.Forms.Label
    Friend WithEvents LabelResourceID As System.Windows.Forms.Label
    Friend WithEvents LabelResourceIDValue As System.Windows.Forms.Label
    Friend WithEvents ComboBoxResourceCategory As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxGeographicRegion As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents ButtonCancel As System.Windows.Forms.Button
    Friend WithEvents LabelResourceLocation As System.Windows.Forms.Label
    Friend WithEvents LabelResourceCategory As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents General As System.Windows.Forms.TabPage
    Friend WithEvents Availability As System.Windows.Forms.TabPage
    Friend WithEvents DateTimePickerPeriodEndDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePickerPeriodStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LabelPeriodEndDate As System.Windows.Forms.Label
    Friend WithEvents LabelPeriodStartDate As System.Windows.Forms.Label
    Friend WithEvents LabelCapacity As System.Windows.Forms.Label
    Friend WithEvents MaskedTextBoxCapacity As System.Windows.Forms.MaskedTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents LabelAvailabilityPeriods As System.Windows.Forms.Label
    Friend WithEvents ButtonDeleteAvailabilityPeriod As System.Windows.Forms.Button
    Friend WithEvents ButtonAddAvailabilityPeriod As System.Windows.Forms.Button
    Friend WithEvents IDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents STARTDATEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ENDDATEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CAPACITYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
