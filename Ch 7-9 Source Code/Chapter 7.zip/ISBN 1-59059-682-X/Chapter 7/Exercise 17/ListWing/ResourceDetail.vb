Public Class ResourceDetail

    Private Sub DateTimePicker2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerPeriodEndDate.ValueChanged

    End Sub
End Class