<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OpenVendor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.buttonCancel = New System.Windows.Forms.Button
        Me.buttonOpen = New System.Windows.Forms.Button
        Me.dataGridViewVendorSearchResults = New System.Windows.Forms.DataGridView
        Me.textBoxContactName = New System.Windows.Forms.TextBox
        Me.textBoxBusinessName = New System.Windows.Forms.TextBox
        Me.textBoxVendorId = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.labelContactName = New System.Windows.Forms.Label
        Me.labelBusinessName = New System.Windows.Forms.Label
        Me.labelVendorId = New System.Windows.Forms.Label
        CType(Me.dataGridViewVendorSearchResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'buttonCancel
        '
        Me.buttonCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.buttonCancel.Location = New System.Drawing.Point(336, 430)
        Me.buttonCancel.Name = "buttonCancel"
        Me.buttonCancel.Size = New System.Drawing.Size(75, 23)
        Me.buttonCancel.TabIndex = 19
        Me.buttonCancel.Text = "Cancel"
        Me.buttonCancel.UseVisualStyleBackColor = True
        '
        'buttonOpen
        '
        Me.buttonOpen.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonOpen.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.buttonOpen.Location = New System.Drawing.Point(431, 430)
        Me.buttonOpen.Name = "buttonOpen"
        Me.buttonOpen.Size = New System.Drawing.Size(75, 23)
        Me.buttonOpen.TabIndex = 18
        Me.buttonOpen.Text = "Open"
        Me.buttonOpen.UseVisualStyleBackColor = True
        '
        'dataGridViewVendorSearchResults
        '
        Me.dataGridViewVendorSearchResults.AllowUserToAddRows = False
        Me.dataGridViewVendorSearchResults.AllowUserToDeleteRows = False
        Me.dataGridViewVendorSearchResults.AllowUserToResizeColumns = False
        Me.dataGridViewVendorSearchResults.AllowUserToResizeRows = False
        Me.dataGridViewVendorSearchResults.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dataGridViewVendorSearchResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewVendorSearchResults.ColumnHeadersVisible = False
        Me.dataGridViewVendorSearchResults.DataMember = "VENDORSEARCH"
        Me.dataGridViewVendorSearchResults.Location = New System.Drawing.Point(33, 110)
        Me.dataGridViewVendorSearchResults.MultiSelect = False
        Me.dataGridViewVendorSearchResults.Name = "dataGridViewVendorSearchResults"
        Me.dataGridViewVendorSearchResults.ReadOnly = True
        Me.dataGridViewVendorSearchResults.RowHeadersWidth = 30
        Me.dataGridViewVendorSearchResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dataGridViewVendorSearchResults.Size = New System.Drawing.Size(473, 299)
        Me.dataGridViewVendorSearchResults.TabIndex = 17
        '
        'textBoxContactName
        '
        Me.textBoxContactName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxContactName.Location = New System.Drawing.Point(336, 72)
        Me.textBoxContactName.Name = "textBoxContactName"
        Me.textBoxContactName.Size = New System.Drawing.Size(170, 20)
        Me.textBoxContactName.TabIndex = 16
        '
        'textBoxBusinessName
        '
        Me.textBoxBusinessName.Location = New System.Drawing.Point(156, 72)
        Me.textBoxBusinessName.Name = "textBoxBusinessName"
        Me.textBoxBusinessName.Size = New System.Drawing.Size(174, 20)
        Me.textBoxBusinessName.TabIndex = 15
        '
        'textBoxVendorId
        '
        Me.textBoxVendorId.Location = New System.Drawing.Point(63, 72)
        Me.textBoxVendorId.Name = "textBoxVendorId"
        Me.textBoxVendorId.Size = New System.Drawing.Size(87, 20)
        Me.textBoxVendorId.TabIndex = 14
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(30, 15)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(76, 13)
        Me.label2.TabIndex = 13
        Me.label2.Text = "Vendor Details"
        '
        'labelContactName
        '
        Me.labelContactName.AutoSize = True
        Me.labelContactName.Location = New System.Drawing.Point(333, 41)
        Me.labelContactName.Name = "labelContactName"
        Me.labelContactName.Size = New System.Drawing.Size(75, 13)
        Me.labelContactName.TabIndex = 12
        Me.labelContactName.Text = "Contact Name"
        '
        'labelBusinessName
        '
        Me.labelBusinessName.AutoSize = True
        Me.labelBusinessName.Location = New System.Drawing.Point(153, 41)
        Me.labelBusinessName.Name = "labelBusinessName"
        Me.labelBusinessName.Size = New System.Drawing.Size(80, 13)
        Me.labelBusinessName.TabIndex = 11
        Me.labelBusinessName.Text = "Business Name"
        '
        'labelVendorId
        '
        Me.labelVendorId.AutoSize = True
        Me.labelVendorId.Location = New System.Drawing.Point(30, 41)
        Me.labelVendorId.Name = "labelVendorId"
        Me.labelVendorId.Size = New System.Drawing.Size(55, 13)
        Me.labelVendorId.TabIndex = 10
        Me.labelVendorId.Text = "Vendor ID"
        '
        'OpenVendor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 468)
        Me.Controls.Add(Me.buttonCancel)
        Me.Controls.Add(Me.buttonOpen)
        Me.Controls.Add(Me.dataGridViewVendorSearchResults)
        Me.Controls.Add(Me.textBoxContactName)
        Me.Controls.Add(Me.textBoxBusinessName)
        Me.Controls.Add(Me.textBoxVendorId)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.labelContactName)
        Me.Controls.Add(Me.labelBusinessName)
        Me.Controls.Add(Me.labelVendorId)
        Me.Name = "OpenVendor"
        Me.Text = "Open Vendor"
        CType(Me.dataGridViewVendorSearchResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents buttonCancel As System.Windows.Forms.Button
    Private WithEvents buttonOpen As System.Windows.Forms.Button
    Private WithEvents dataGridViewVendorSearchResults As System.Windows.Forms.DataGridView
    Private WithEvents textBoxContactName As System.Windows.Forms.TextBox
    Private WithEvents textBoxBusinessName As System.Windows.Forms.TextBox
    Private WithEvents textBoxVendorId As System.Windows.Forms.TextBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents labelContactName As System.Windows.Forms.Label
    Private WithEvents labelBusinessName As System.Windows.Forms.Label
    Private WithEvents labelVendorId As System.Windows.Forms.Label
End Class
