Public Class VendorDetails

    Public Event CloseVendor As VendorDetailsEventHandler

    Public Delegate Sub VendorDetailsEventHandler(ByVal sender As VendorDetails)

    Private Sub buttonOpenResource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonOpenResource.Click

    End Sub

    Private Sub buttonNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonNew.Click

    End Sub

    Private Sub buttonClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonClose.Click
        RaiseEvent CloseVendor(Me)
    End Sub
End Class
