Public Class VendorContacts

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub OpenVendorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenVendorToolStripMenuItem.Click
        If OpenVendor.ShowDialog() = Windows.Forms.DialogResult.OK Then

            Dim newPage As TabPage
            Dim vendorDetails As VendorDetails

            newPage = New TabPage()
            vendorDetails = New VendorDetails()
            vendorDetails.Dock = DockStyle.Fill
            AddHandler vendorDetails.CloseVendor, AddressOf OnCloseVendor
            newPage.Controls.Add(vendorDetails)
            Me.tabControlVendors.TabPages.Add(newPage)

        End If
    End Sub

    Public Sub OnCloseVendor(ByVal vendorDetails As VendorDetails)
        Me.tabControlVendors.TabPages.Remove(vendorDetails.Parent)
    End Sub

End Class