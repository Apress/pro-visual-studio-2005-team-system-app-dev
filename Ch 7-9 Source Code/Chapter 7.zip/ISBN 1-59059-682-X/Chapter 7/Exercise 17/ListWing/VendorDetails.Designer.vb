<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VendorDetails
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.labelVendorNameValue = New System.Windows.Forms.Label
        Me.labelVendorIdValue = New System.Windows.Forms.Label
        Me.labelVendorName = New System.Windows.Forms.Label
        Me.labelVendorId = New System.Windows.Forms.Label
        Me.buttonClose = New System.Windows.Forms.Button
        Me.tabControl1 = New System.Windows.Forms.TabControl
        Me.tabPageGeneralDetails = New System.Windows.Forms.TabPage
        Me.groupBoxEmail = New System.Windows.Forms.GroupBox
        Me.textBoxEmailAddress = New System.Windows.Forms.TextBox
        Me.labelEmailAddress = New System.Windows.Forms.Label
        Me.textBoxVendorContactName = New System.Windows.Forms.TextBox
        Me.textBoxVendorBusinessName = New System.Windows.Forms.TextBox
        Me.groupBoxTelephone = New System.Windows.Forms.GroupBox
        Me.textBoxMobileNumber = New System.Windows.Forms.TextBox
        Me.textBoxMobileAreaCode = New System.Windows.Forms.TextBox
        Me.textBoxMobileCountryCode = New System.Windows.Forms.TextBox
        Me.labelMobileNumber = New System.Windows.Forms.Label
        Me.labelMobileAreaCode = New System.Windows.Forms.Label
        Me.labelMobilePhone = New System.Windows.Forms.Label
        Me.textBoxContactNumber = New System.Windows.Forms.TextBox
        Me.textBoxContactAreaCode = New System.Windows.Forms.TextBox
        Me.textBoxContactCountryCode = New System.Windows.Forms.TextBox
        Me.labelWorkNumber = New System.Windows.Forms.Label
        Me.labelWorkAreaCode = New System.Windows.Forms.Label
        Me.labelContactPhone = New System.Windows.Forms.Label
        Me.textBoxOfficeNumber = New System.Windows.Forms.TextBox
        Me.textBoxOfficeAreaCode = New System.Windows.Forms.TextBox
        Me.textBoxOfficeCountryCode = New System.Windows.Forms.TextBox
        Me.labelHomeNumber = New System.Windows.Forms.Label
        Me.labelHomeAreaCode = New System.Windows.Forms.Label
        Me.labelOfficePhone = New System.Windows.Forms.Label
        Me.labelVendorContactName = New System.Windows.Forms.Label
        Me.labelVendorBusinessName = New System.Windows.Forms.Label
        Me.tabPageBusinessAddress = New System.Windows.Forms.TabPage
        Me.labelPostalCode = New System.Windows.Forms.Label
        Me.textBoxBPostalCode = New System.Windows.Forms.TextBox
        Me.textBoxBSteetAddressLine1 = New System.Windows.Forms.TextBox
        Me.labelCountry = New System.Windows.Forms.Label
        Me.labelStreetAddress = New System.Windows.Forms.Label
        Me.comboBoxBCountry = New System.Windows.Forms.ComboBox
        Me.textBoxBSteetAddressLine2 = New System.Windows.Forms.TextBox
        Me.labelRegion = New System.Windows.Forms.Label
        Me.textBoxBCity = New System.Windows.Forms.TextBox
        Me.textBoxBRegion = New System.Windows.Forms.TextBox
        Me.labelCity = New System.Windows.Forms.Label
        Me.labelState = New System.Windows.Forms.Label
        Me.comboBoxBState = New System.Windows.Forms.ComboBox
        Me.tabPageMailingAddress = New System.Windows.Forms.TabPage
        Me.labelMPostalCode = New System.Windows.Forms.Label
        Me.textBoxMPostalCode = New System.Windows.Forms.TextBox
        Me.textBoxMStreetAddressLine1 = New System.Windows.Forms.TextBox
        Me.labelMCountry = New System.Windows.Forms.Label
        Me.labelMStreetAddress1 = New System.Windows.Forms.Label
        Me.comboBoxMCountry = New System.Windows.Forms.ComboBox
        Me.textBoxMStreetAddressLine2 = New System.Windows.Forms.TextBox
        Me.labelMRegion = New System.Windows.Forms.Label
        Me.textBoxMCity = New System.Windows.Forms.TextBox
        Me.textBoxMRegion = New System.Windows.Forms.TextBox
        Me.labelMCity = New System.Windows.Forms.Label
        Me.labelMState = New System.Windows.Forms.Label
        Me.comboBoxMState = New System.Windows.Forms.ComboBox
        Me.tabPagePaymentInformation = New System.Windows.Forms.TabPage
        Me.tabPageResources = New System.Windows.Forms.TabPage
        Me.labelListedResources = New System.Windows.Forms.Label
        Me.buttonNew = New System.Windows.Forms.Button
        Me.buttonOpenResource = New System.Windows.Forms.Button
        Me.dataGridViewResources = New System.Windows.Forms.DataGridView
        Me.tabControl1.SuspendLayout()
        Me.tabPageGeneralDetails.SuspendLayout()
        Me.groupBoxEmail.SuspendLayout()
        Me.groupBoxTelephone.SuspendLayout()
        Me.tabPageBusinessAddress.SuspendLayout()
        Me.tabPageMailingAddress.SuspendLayout()
        Me.tabPageResources.SuspendLayout()
        CType(Me.dataGridViewResources, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'labelVendorNameValue
        '
        Me.labelVendorNameValue.AutoSize = True
        Me.labelVendorNameValue.Location = New System.Drawing.Point(123, 32)
        Me.labelVendorNameValue.Name = "labelVendorNameValue"
        Me.labelVendorNameValue.Size = New System.Drawing.Size(0, 13)
        Me.labelVendorNameValue.TabIndex = 21
        '
        'labelVendorIdValue
        '
        Me.labelVendorIdValue.AutoSize = True
        Me.labelVendorIdValue.Location = New System.Drawing.Point(123, 8)
        Me.labelVendorIdValue.Name = "labelVendorIdValue"
        Me.labelVendorIdValue.Size = New System.Drawing.Size(0, 13)
        Me.labelVendorIdValue.TabIndex = 20
        '
        'labelVendorName
        '
        Me.labelVendorName.AutoSize = True
        Me.labelVendorName.Location = New System.Drawing.Point(16, 32)
        Me.labelVendorName.Name = "labelVendorName"
        Me.labelVendorName.Size = New System.Drawing.Size(72, 13)
        Me.labelVendorName.TabIndex = 19
        Me.labelVendorName.Text = "Vendor Name"
        '
        'labelVendorId
        '
        Me.labelVendorId.AutoSize = True
        Me.labelVendorId.Location = New System.Drawing.Point(17, 8)
        Me.labelVendorId.Name = "labelVendorId"
        Me.labelVendorId.Size = New System.Drawing.Size(55, 13)
        Me.labelVendorId.TabIndex = 18
        Me.labelVendorId.Text = "Vendor ID"
        '
        'buttonClose
        '
        Me.buttonClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonClose.Location = New System.Drawing.Point(406, 327)
        Me.buttonClose.Name = "buttonClose"
        Me.buttonClose.Size = New System.Drawing.Size(75, 23)
        Me.buttonClose.TabIndex = 17
        Me.buttonClose.Text = "Close"
        Me.buttonClose.UseVisualStyleBackColor = True
        '
        'tabControl1
        '
        Me.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl1.Controls.Add(Me.tabPageGeneralDetails)
        Me.tabControl1.Controls.Add(Me.tabPageBusinessAddress)
        Me.tabControl1.Controls.Add(Me.tabPageMailingAddress)
        Me.tabControl1.Controls.Add(Me.tabPagePaymentInformation)
        Me.tabControl1.Controls.Add(Me.tabPageResources)
        Me.tabControl1.Location = New System.Drawing.Point(3, 52)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(494, 267)
        Me.tabControl1.TabIndex = 16
        '
        'tabPageGeneralDetails
        '
        Me.tabPageGeneralDetails.Controls.Add(Me.groupBoxEmail)
        Me.tabPageGeneralDetails.Controls.Add(Me.textBoxVendorContactName)
        Me.tabPageGeneralDetails.Controls.Add(Me.textBoxVendorBusinessName)
        Me.tabPageGeneralDetails.Controls.Add(Me.groupBoxTelephone)
        Me.tabPageGeneralDetails.Controls.Add(Me.labelVendorContactName)
        Me.tabPageGeneralDetails.Controls.Add(Me.labelVendorBusinessName)
        Me.tabPageGeneralDetails.Location = New System.Drawing.Point(4, 4)
        Me.tabPageGeneralDetails.Name = "tabPageGeneralDetails"
        Me.tabPageGeneralDetails.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPageGeneralDetails.Size = New System.Drawing.Size(486, 241)
        Me.tabPageGeneralDetails.TabIndex = 0
        Me.tabPageGeneralDetails.Text = "General Details"
        Me.tabPageGeneralDetails.UseVisualStyleBackColor = True
        '
        'groupBoxEmail
        '
        Me.groupBoxEmail.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBoxEmail.Controls.Add(Me.textBoxEmailAddress)
        Me.groupBoxEmail.Controls.Add(Me.labelEmailAddress)
        Me.groupBoxEmail.Location = New System.Drawing.Point(16, 178)
        Me.groupBoxEmail.Name = "groupBoxEmail"
        Me.groupBoxEmail.Size = New System.Drawing.Size(458, 54)
        Me.groupBoxEmail.TabIndex = 18
        Me.groupBoxEmail.TabStop = False
        Me.groupBoxEmail.Text = "Email"
        '
        'textBoxEmailAddress
        '
        Me.textBoxEmailAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxEmailAddress.Location = New System.Drawing.Point(122, 18)
        Me.textBoxEmailAddress.Name = "textBoxEmailAddress"
        Me.textBoxEmailAddress.Size = New System.Drawing.Size(321, 20)
        Me.textBoxEmailAddress.TabIndex = 5
        '
        'labelEmailAddress
        '
        Me.labelEmailAddress.AutoSize = True
        Me.labelEmailAddress.Location = New System.Drawing.Point(10, 21)
        Me.labelEmailAddress.Name = "labelEmailAddress"
        Me.labelEmailAddress.Size = New System.Drawing.Size(72, 13)
        Me.labelEmailAddress.TabIndex = 2
        Me.labelEmailAddress.Text = "Email address"
        '
        'textBoxVendorContactName
        '
        Me.textBoxVendorContactName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxVendorContactName.Location = New System.Drawing.Point(138, 37)
        Me.textBoxVendorContactName.Name = "textBoxVendorContactName"
        Me.textBoxVendorContactName.Size = New System.Drawing.Size(321, 20)
        Me.textBoxVendorContactName.TabIndex = 17
        '
        'textBoxVendorBusinessName
        '
        Me.textBoxVendorBusinessName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxVendorBusinessName.Location = New System.Drawing.Point(138, 11)
        Me.textBoxVendorBusinessName.Name = "textBoxVendorBusinessName"
        Me.textBoxVendorBusinessName.Size = New System.Drawing.Size(321, 20)
        Me.textBoxVendorBusinessName.TabIndex = 16
        '
        'groupBoxTelephone
        '
        Me.groupBoxTelephone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxMobileNumber)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxMobileAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxMobileCountryCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelMobileNumber)
        Me.groupBoxTelephone.Controls.Add(Me.labelMobileAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelMobilePhone)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxContactNumber)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxContactAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxContactCountryCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelWorkNumber)
        Me.groupBoxTelephone.Controls.Add(Me.labelWorkAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelContactPhone)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxOfficeNumber)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxOfficeAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.textBoxOfficeCountryCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelHomeNumber)
        Me.groupBoxTelephone.Controls.Add(Me.labelHomeAreaCode)
        Me.groupBoxTelephone.Controls.Add(Me.labelOfficePhone)
        Me.groupBoxTelephone.Location = New System.Drawing.Point(16, 67)
        Me.groupBoxTelephone.Name = "groupBoxTelephone"
        Me.groupBoxTelephone.Size = New System.Drawing.Size(458, 100)
        Me.groupBoxTelephone.TabIndex = 15
        Me.groupBoxTelephone.TabStop = False
        Me.groupBoxTelephone.Text = "Telephone"
        '
        'textBoxMobileNumber
        '
        Me.textBoxMobileNumber.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMobileNumber.Location = New System.Drawing.Point(368, 69)
        Me.textBoxMobileNumber.Name = "textBoxMobileNumber"
        Me.textBoxMobileNumber.Size = New System.Drawing.Size(75, 20)
        Me.textBoxMobileNumber.TabIndex = 19
        '
        'textBoxMobileAreaCode
        '
        Me.textBoxMobileAreaCode.Location = New System.Drawing.Point(237, 69)
        Me.textBoxMobileAreaCode.Name = "textBoxMobileAreaCode"
        Me.textBoxMobileAreaCode.Size = New System.Drawing.Size(75, 20)
        Me.textBoxMobileAreaCode.TabIndex = 18
        '
        'textBoxMobileCountryCode
        '
        Me.textBoxMobileCountryCode.Location = New System.Drawing.Point(122, 69)
        Me.textBoxMobileCountryCode.Name = "textBoxMobileCountryCode"
        Me.textBoxMobileCountryCode.Size = New System.Drawing.Size(46, 20)
        Me.textBoxMobileCountryCode.TabIndex = 17
        '
        'labelMobileNumber
        '
        Me.labelMobileNumber.AutoSize = True
        Me.labelMobileNumber.Location = New System.Drawing.Point(318, 72)
        Me.labelMobileNumber.Name = "labelMobileNumber"
        Me.labelMobileNumber.Size = New System.Drawing.Size(44, 13)
        Me.labelMobileNumber.TabIndex = 16
        Me.labelMobileNumber.Text = "Number"
        '
        'labelMobileAreaCode
        '
        Me.labelMobileAreaCode.AutoSize = True
        Me.labelMobileAreaCode.Location = New System.Drawing.Point(174, 72)
        Me.labelMobileAreaCode.Name = "labelMobileAreaCode"
        Me.labelMobileAreaCode.Size = New System.Drawing.Size(57, 13)
        Me.labelMobileAreaCode.TabIndex = 15
        Me.labelMobileAreaCode.Text = "Area Code"
        '
        'labelMobilePhone
        '
        Me.labelMobilePhone.AutoSize = True
        Me.labelMobilePhone.Location = New System.Drawing.Point(10, 72)
        Me.labelMobilePhone.Name = "labelMobilePhone"
        Me.labelMobilePhone.Size = New System.Drawing.Size(108, 13)
        Me.labelMobilePhone.TabIndex = 14
        Me.labelMobilePhone.Text = "Mobile: Country Code"
        '
        'textBoxContactNumber
        '
        Me.textBoxContactNumber.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxContactNumber.Location = New System.Drawing.Point(368, 43)
        Me.textBoxContactNumber.Name = "textBoxContactNumber"
        Me.textBoxContactNumber.Size = New System.Drawing.Size(75, 20)
        Me.textBoxContactNumber.TabIndex = 13
        '
        'textBoxContactAreaCode
        '
        Me.textBoxContactAreaCode.Location = New System.Drawing.Point(237, 43)
        Me.textBoxContactAreaCode.Name = "textBoxContactAreaCode"
        Me.textBoxContactAreaCode.Size = New System.Drawing.Size(75, 20)
        Me.textBoxContactAreaCode.TabIndex = 12
        '
        'textBoxContactCountryCode
        '
        Me.textBoxContactCountryCode.Location = New System.Drawing.Point(122, 43)
        Me.textBoxContactCountryCode.Name = "textBoxContactCountryCode"
        Me.textBoxContactCountryCode.Size = New System.Drawing.Size(46, 20)
        Me.textBoxContactCountryCode.TabIndex = 11
        '
        'labelWorkNumber
        '
        Me.labelWorkNumber.AutoSize = True
        Me.labelWorkNumber.Location = New System.Drawing.Point(318, 46)
        Me.labelWorkNumber.Name = "labelWorkNumber"
        Me.labelWorkNumber.Size = New System.Drawing.Size(44, 13)
        Me.labelWorkNumber.TabIndex = 10
        Me.labelWorkNumber.Text = "Number"
        '
        'labelWorkAreaCode
        '
        Me.labelWorkAreaCode.AutoSize = True
        Me.labelWorkAreaCode.Location = New System.Drawing.Point(174, 46)
        Me.labelWorkAreaCode.Name = "labelWorkAreaCode"
        Me.labelWorkAreaCode.Size = New System.Drawing.Size(57, 13)
        Me.labelWorkAreaCode.TabIndex = 9
        Me.labelWorkAreaCode.Text = "Area Code"
        '
        'labelContactPhone
        '
        Me.labelContactPhone.AutoSize = True
        Me.labelContactPhone.Location = New System.Drawing.Point(10, 46)
        Me.labelContactPhone.Name = "labelContactPhone"
        Me.labelContactPhone.Size = New System.Drawing.Size(114, 13)
        Me.labelContactPhone.TabIndex = 8
        Me.labelContactPhone.Text = "Contact: Country Code"
        '
        'textBoxOfficeNumber
        '
        Me.textBoxOfficeNumber.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxOfficeNumber.Location = New System.Drawing.Point(368, 18)
        Me.textBoxOfficeNumber.Name = "textBoxOfficeNumber"
        Me.textBoxOfficeNumber.Size = New System.Drawing.Size(75, 20)
        Me.textBoxOfficeNumber.TabIndex = 7
        '
        'textBoxOfficeAreaCode
        '
        Me.textBoxOfficeAreaCode.Location = New System.Drawing.Point(237, 18)
        Me.textBoxOfficeAreaCode.Name = "textBoxOfficeAreaCode"
        Me.textBoxOfficeAreaCode.Size = New System.Drawing.Size(75, 20)
        Me.textBoxOfficeAreaCode.TabIndex = 6
        '
        'textBoxOfficeCountryCode
        '
        Me.textBoxOfficeCountryCode.Location = New System.Drawing.Point(122, 18)
        Me.textBoxOfficeCountryCode.Name = "textBoxOfficeCountryCode"
        Me.textBoxOfficeCountryCode.Size = New System.Drawing.Size(46, 20)
        Me.textBoxOfficeCountryCode.TabIndex = 5
        '
        'labelHomeNumber
        '
        Me.labelHomeNumber.AutoSize = True
        Me.labelHomeNumber.Location = New System.Drawing.Point(318, 21)
        Me.labelHomeNumber.Name = "labelHomeNumber"
        Me.labelHomeNumber.Size = New System.Drawing.Size(44, 13)
        Me.labelHomeNumber.TabIndex = 4
        Me.labelHomeNumber.Text = "Number"
        '
        'labelHomeAreaCode
        '
        Me.labelHomeAreaCode.AutoSize = True
        Me.labelHomeAreaCode.Location = New System.Drawing.Point(174, 21)
        Me.labelHomeAreaCode.Name = "labelHomeAreaCode"
        Me.labelHomeAreaCode.Size = New System.Drawing.Size(57, 13)
        Me.labelHomeAreaCode.TabIndex = 3
        Me.labelHomeAreaCode.Text = "Area Code"
        '
        'labelOfficePhone
        '
        Me.labelOfficePhone.AutoSize = True
        Me.labelOfficePhone.Location = New System.Drawing.Point(10, 21)
        Me.labelOfficePhone.Name = "labelOfficePhone"
        Me.labelOfficePhone.Size = New System.Drawing.Size(105, 13)
        Me.labelOfficePhone.TabIndex = 2
        Me.labelOfficePhone.Text = "Office: Country Code"
        '
        'labelVendorContactName
        '
        Me.labelVendorContactName.AutoSize = True
        Me.labelVendorContactName.Location = New System.Drawing.Point(13, 40)
        Me.labelVendorContactName.Name = "labelVendorContactName"
        Me.labelVendorContactName.Size = New System.Drawing.Size(112, 13)
        Me.labelVendorContactName.TabIndex = 14
        Me.labelVendorContactName.Text = "Vendor Contact Name"
        '
        'labelVendorBusinessName
        '
        Me.labelVendorBusinessName.AutoSize = True
        Me.labelVendorBusinessName.Location = New System.Drawing.Point(13, 14)
        Me.labelVendorBusinessName.Name = "labelVendorBusinessName"
        Me.labelVendorBusinessName.Size = New System.Drawing.Size(117, 13)
        Me.labelVendorBusinessName.TabIndex = 13
        Me.labelVendorBusinessName.Text = "Vendor Business Name"
        '
        'tabPageBusinessAddress
        '
        Me.tabPageBusinessAddress.Controls.Add(Me.labelPostalCode)
        Me.tabPageBusinessAddress.Controls.Add(Me.textBoxBPostalCode)
        Me.tabPageBusinessAddress.Controls.Add(Me.textBoxBSteetAddressLine1)
        Me.tabPageBusinessAddress.Controls.Add(Me.labelCountry)
        Me.tabPageBusinessAddress.Controls.Add(Me.labelStreetAddress)
        Me.tabPageBusinessAddress.Controls.Add(Me.comboBoxBCountry)
        Me.tabPageBusinessAddress.Controls.Add(Me.textBoxBSteetAddressLine2)
        Me.tabPageBusinessAddress.Controls.Add(Me.labelRegion)
        Me.tabPageBusinessAddress.Controls.Add(Me.textBoxBCity)
        Me.tabPageBusinessAddress.Controls.Add(Me.textBoxBRegion)
        Me.tabPageBusinessAddress.Controls.Add(Me.labelCity)
        Me.tabPageBusinessAddress.Controls.Add(Me.labelState)
        Me.tabPageBusinessAddress.Controls.Add(Me.comboBoxBState)
        Me.tabPageBusinessAddress.Location = New System.Drawing.Point(4, 4)
        Me.tabPageBusinessAddress.Name = "tabPageBusinessAddress"
        Me.tabPageBusinessAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPageBusinessAddress.Size = New System.Drawing.Size(486, 241)
        Me.tabPageBusinessAddress.TabIndex = 1
        Me.tabPageBusinessAddress.Text = "Business Address"
        Me.tabPageBusinessAddress.UseVisualStyleBackColor = True
        '
        'labelPostalCode
        '
        Me.labelPostalCode.AutoSize = True
        Me.labelPostalCode.Location = New System.Drawing.Point(10, 181)
        Me.labelPostalCode.Name = "labelPostalCode"
        Me.labelPostalCode.Size = New System.Drawing.Size(64, 13)
        Me.labelPostalCode.TabIndex = 38
        Me.labelPostalCode.Text = "Postal Code"
        '
        'textBoxBPostalCode
        '
        Me.textBoxBPostalCode.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxBPostalCode.Location = New System.Drawing.Point(129, 178)
        Me.textBoxBPostalCode.Name = "textBoxBPostalCode"
        Me.textBoxBPostalCode.Size = New System.Drawing.Size(175, 20)
        Me.textBoxBPostalCode.TabIndex = 37
        '
        'textBoxBSteetAddressLine1
        '
        Me.textBoxBSteetAddressLine1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxBSteetAddressLine1.Location = New System.Drawing.Point(129, 7)
        Me.textBoxBSteetAddressLine1.Name = "textBoxBSteetAddressLine1"
        Me.textBoxBSteetAddressLine1.Size = New System.Drawing.Size(348, 20)
        Me.textBoxBSteetAddressLine1.TabIndex = 27
        '
        'labelCountry
        '
        Me.labelCountry.AutoSize = True
        Me.labelCountry.Location = New System.Drawing.Point(9, 215)
        Me.labelCountry.Name = "labelCountry"
        Me.labelCountry.Size = New System.Drawing.Size(43, 13)
        Me.labelCountry.TabIndex = 36
        Me.labelCountry.Text = "Country"
        '
        'labelStreetAddress
        '
        Me.labelStreetAddress.AutoSize = True
        Me.labelStreetAddress.Location = New System.Drawing.Point(9, 10)
        Me.labelStreetAddress.Name = "labelStreetAddress"
        Me.labelStreetAddress.Size = New System.Drawing.Size(76, 13)
        Me.labelStreetAddress.TabIndex = 26
        Me.labelStreetAddress.Text = "Street Address"
        '
        'comboBoxBCountry
        '
        Me.comboBoxBCountry.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxBCountry.DisplayMember = "COUNTRIES.NAME"
        Me.comboBoxBCountry.FormattingEnabled = True
        Me.comboBoxBCountry.Location = New System.Drawing.Point(129, 212)
        Me.comboBoxBCountry.Name = "comboBoxBCountry"
        Me.comboBoxBCountry.Size = New System.Drawing.Size(175, 21)
        Me.comboBoxBCountry.TabIndex = 35
        Me.comboBoxBCountry.ValueMember = "COUNTRIES.ID"
        '
        'textBoxBSteetAddressLine2
        '
        Me.textBoxBSteetAddressLine2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxBSteetAddressLine2.Location = New System.Drawing.Point(129, 41)
        Me.textBoxBSteetAddressLine2.Name = "textBoxBSteetAddressLine2"
        Me.textBoxBSteetAddressLine2.Size = New System.Drawing.Size(348, 20)
        Me.textBoxBSteetAddressLine2.TabIndex = 28
        '
        'labelRegion
        '
        Me.labelRegion.AutoSize = True
        Me.labelRegion.Location = New System.Drawing.Point(10, 112)
        Me.labelRegion.Name = "labelRegion"
        Me.labelRegion.Size = New System.Drawing.Size(113, 13)
        Me.labelRegion.TabIndex = 34
        Me.labelRegion.Text = "Region (Province etc.)"
        '
        'textBoxBCity
        '
        Me.textBoxBCity.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxBCity.Location = New System.Drawing.Point(129, 75)
        Me.textBoxBCity.Name = "textBoxBCity"
        Me.textBoxBCity.Size = New System.Drawing.Size(348, 20)
        Me.textBoxBCity.TabIndex = 29
        '
        'textBoxBRegion
        '
        Me.textBoxBRegion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxBRegion.Location = New System.Drawing.Point(129, 109)
        Me.textBoxBRegion.Name = "textBoxBRegion"
        Me.textBoxBRegion.Size = New System.Drawing.Size(348, 20)
        Me.textBoxBRegion.TabIndex = 33
        '
        'labelCity
        '
        Me.labelCity.AutoSize = True
        Me.labelCity.Location = New System.Drawing.Point(10, 78)
        Me.labelCity.Name = "labelCity"
        Me.labelCity.Size = New System.Drawing.Size(24, 13)
        Me.labelCity.TabIndex = 30
        Me.labelCity.Text = "City"
        '
        'labelState
        '
        Me.labelState.AutoSize = True
        Me.labelState.Location = New System.Drawing.Point(9, 146)
        Me.labelState.Name = "labelState"
        Me.labelState.Size = New System.Drawing.Size(78, 13)
        Me.labelState.TabIndex = 32
        Me.labelState.Text = "State (US only)"
        '
        'comboBoxBState
        '
        Me.comboBoxBState.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxBState.DisplayMember = "STATES.NAME"
        Me.comboBoxBState.FormattingEnabled = True
        Me.comboBoxBState.Location = New System.Drawing.Point(129, 143)
        Me.comboBoxBState.Name = "comboBoxBState"
        Me.comboBoxBState.Size = New System.Drawing.Size(175, 21)
        Me.comboBoxBState.TabIndex = 31
        Me.comboBoxBState.ValueMember = "STATES.ID"
        '
        'tabPageMailingAddress
        '
        Me.tabPageMailingAddress.Controls.Add(Me.labelMPostalCode)
        Me.tabPageMailingAddress.Controls.Add(Me.textBoxMPostalCode)
        Me.tabPageMailingAddress.Controls.Add(Me.textBoxMStreetAddressLine1)
        Me.tabPageMailingAddress.Controls.Add(Me.labelMCountry)
        Me.tabPageMailingAddress.Controls.Add(Me.labelMStreetAddress1)
        Me.tabPageMailingAddress.Controls.Add(Me.comboBoxMCountry)
        Me.tabPageMailingAddress.Controls.Add(Me.textBoxMStreetAddressLine2)
        Me.tabPageMailingAddress.Controls.Add(Me.labelMRegion)
        Me.tabPageMailingAddress.Controls.Add(Me.textBoxMCity)
        Me.tabPageMailingAddress.Controls.Add(Me.textBoxMRegion)
        Me.tabPageMailingAddress.Controls.Add(Me.labelMCity)
        Me.tabPageMailingAddress.Controls.Add(Me.labelMState)
        Me.tabPageMailingAddress.Controls.Add(Me.comboBoxMState)
        Me.tabPageMailingAddress.Location = New System.Drawing.Point(4, 4)
        Me.tabPageMailingAddress.Name = "tabPageMailingAddress"
        Me.tabPageMailingAddress.Size = New System.Drawing.Size(486, 241)
        Me.tabPageMailingAddress.TabIndex = 2
        Me.tabPageMailingAddress.Text = "Mailing Address"
        Me.tabPageMailingAddress.UseVisualStyleBackColor = True
        '
        'labelMPostalCode
        '
        Me.labelMPostalCode.AutoSize = True
        Me.labelMPostalCode.Location = New System.Drawing.Point(10, 181)
        Me.labelMPostalCode.Name = "labelMPostalCode"
        Me.labelMPostalCode.Size = New System.Drawing.Size(64, 13)
        Me.labelMPostalCode.TabIndex = 51
        Me.labelMPostalCode.Text = "Postal Code"
        '
        'textBoxMPostalCode
        '
        Me.textBoxMPostalCode.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMPostalCode.Location = New System.Drawing.Point(129, 178)
        Me.textBoxMPostalCode.Name = "textBoxMPostalCode"
        Me.textBoxMPostalCode.Size = New System.Drawing.Size(175, 20)
        Me.textBoxMPostalCode.TabIndex = 50
        '
        'textBoxMStreetAddressLine1
        '
        Me.textBoxMStreetAddressLine1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMStreetAddressLine1.Location = New System.Drawing.Point(129, 7)
        Me.textBoxMStreetAddressLine1.Name = "textBoxMStreetAddressLine1"
        Me.textBoxMStreetAddressLine1.Size = New System.Drawing.Size(348, 20)
        Me.textBoxMStreetAddressLine1.TabIndex = 40
        '
        'labelMCountry
        '
        Me.labelMCountry.AutoSize = True
        Me.labelMCountry.Location = New System.Drawing.Point(9, 215)
        Me.labelMCountry.Name = "labelMCountry"
        Me.labelMCountry.Size = New System.Drawing.Size(43, 13)
        Me.labelMCountry.TabIndex = 49
        Me.labelMCountry.Text = "Country"
        '
        'labelMStreetAddress1
        '
        Me.labelMStreetAddress1.AutoSize = True
        Me.labelMStreetAddress1.Location = New System.Drawing.Point(9, 10)
        Me.labelMStreetAddress1.Name = "labelMStreetAddress1"
        Me.labelMStreetAddress1.Size = New System.Drawing.Size(76, 13)
        Me.labelMStreetAddress1.TabIndex = 39
        Me.labelMStreetAddress1.Text = "Street Address"
        '
        'comboBoxMCountry
        '
        Me.comboBoxMCountry.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxMCountry.DisplayMember = "COUNTRIES.NAME"
        Me.comboBoxMCountry.FormattingEnabled = True
        Me.comboBoxMCountry.Location = New System.Drawing.Point(129, 212)
        Me.comboBoxMCountry.Name = "comboBoxMCountry"
        Me.comboBoxMCountry.Size = New System.Drawing.Size(175, 21)
        Me.comboBoxMCountry.TabIndex = 48
        Me.comboBoxMCountry.ValueMember = "COUNTRIES.ID"
        '
        'textBoxMStreetAddressLine2
        '
        Me.textBoxMStreetAddressLine2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMStreetAddressLine2.Location = New System.Drawing.Point(129, 41)
        Me.textBoxMStreetAddressLine2.Name = "textBoxMStreetAddressLine2"
        Me.textBoxMStreetAddressLine2.Size = New System.Drawing.Size(348, 20)
        Me.textBoxMStreetAddressLine2.TabIndex = 41
        '
        'labelMRegion
        '
        Me.labelMRegion.AutoSize = True
        Me.labelMRegion.Location = New System.Drawing.Point(10, 112)
        Me.labelMRegion.Name = "labelMRegion"
        Me.labelMRegion.Size = New System.Drawing.Size(113, 13)
        Me.labelMRegion.TabIndex = 47
        Me.labelMRegion.Text = "Region (Province etc.)"
        '
        'textBoxMCity
        '
        Me.textBoxMCity.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMCity.Location = New System.Drawing.Point(129, 75)
        Me.textBoxMCity.Name = "textBoxMCity"
        Me.textBoxMCity.Size = New System.Drawing.Size(348, 20)
        Me.textBoxMCity.TabIndex = 42
        '
        'textBoxMRegion
        '
        Me.textBoxMRegion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMRegion.Location = New System.Drawing.Point(129, 109)
        Me.textBoxMRegion.Name = "textBoxMRegion"
        Me.textBoxMRegion.Size = New System.Drawing.Size(348, 20)
        Me.textBoxMRegion.TabIndex = 46
        '
        'labelMCity
        '
        Me.labelMCity.AutoSize = True
        Me.labelMCity.Location = New System.Drawing.Point(10, 78)
        Me.labelMCity.Name = "labelMCity"
        Me.labelMCity.Size = New System.Drawing.Size(24, 13)
        Me.labelMCity.TabIndex = 43
        Me.labelMCity.Text = "City"
        '
        'labelMState
        '
        Me.labelMState.AutoSize = True
        Me.labelMState.Location = New System.Drawing.Point(9, 146)
        Me.labelMState.Name = "labelMState"
        Me.labelMState.Size = New System.Drawing.Size(78, 13)
        Me.labelMState.TabIndex = 45
        Me.labelMState.Text = "State (US only)"
        '
        'comboBoxMState
        '
        Me.comboBoxMState.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxMState.DisplayMember = "STATES.NAME"
        Me.comboBoxMState.FormattingEnabled = True
        Me.comboBoxMState.Location = New System.Drawing.Point(129, 143)
        Me.comboBoxMState.Name = "comboBoxMState"
        Me.comboBoxMState.Size = New System.Drawing.Size(175, 21)
        Me.comboBoxMState.TabIndex = 44
        Me.comboBoxMState.ValueMember = "STATES.ID"
        '
        'tabPagePaymentInformation
        '
        Me.tabPagePaymentInformation.Location = New System.Drawing.Point(4, 4)
        Me.tabPagePaymentInformation.Name = "tabPagePaymentInformation"
        Me.tabPagePaymentInformation.Size = New System.Drawing.Size(486, 241)
        Me.tabPagePaymentInformation.TabIndex = 3
        Me.tabPagePaymentInformation.Text = "Payment Information"
        Me.tabPagePaymentInformation.UseVisualStyleBackColor = True
        '
        'tabPageResources
        '
        Me.tabPageResources.Controls.Add(Me.labelListedResources)
        Me.tabPageResources.Controls.Add(Me.buttonNew)
        Me.tabPageResources.Controls.Add(Me.buttonOpenResource)
        Me.tabPageResources.Controls.Add(Me.dataGridViewResources)
        Me.tabPageResources.Location = New System.Drawing.Point(4, 4)
        Me.tabPageResources.Name = "tabPageResources"
        Me.tabPageResources.Size = New System.Drawing.Size(486, 241)
        Me.tabPageResources.TabIndex = 4
        Me.tabPageResources.Text = "Resources"
        Me.tabPageResources.UseVisualStyleBackColor = True
        '
        'labelListedResources
        '
        Me.labelListedResources.AutoSize = True
        Me.labelListedResources.Location = New System.Drawing.Point(13, 8)
        Me.labelListedResources.Name = "labelListedResources"
        Me.labelListedResources.Size = New System.Drawing.Size(89, 13)
        Me.labelListedResources.TabIndex = 11
        Me.labelListedResources.Text = "Listed Resources"
        '
        'buttonNew
        '
        Me.buttonNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonNew.Location = New System.Drawing.Point(399, 210)
        Me.buttonNew.Name = "buttonNew"
        Me.buttonNew.Size = New System.Drawing.Size(75, 23)
        Me.buttonNew.TabIndex = 10
        Me.buttonNew.Text = "New ..."
        Me.buttonNew.UseVisualStyleBackColor = True
        '
        'buttonOpenResource
        '
        Me.buttonOpenResource.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonOpenResource.Location = New System.Drawing.Point(399, 170)
        Me.buttonOpenResource.Name = "buttonOpenResource"
        Me.buttonOpenResource.Size = New System.Drawing.Size(75, 23)
        Me.buttonOpenResource.TabIndex = 9
        Me.buttonOpenResource.Text = "Open"
        Me.buttonOpenResource.UseVisualStyleBackColor = True
        '
        'dataGridViewResources
        '
        Me.dataGridViewResources.AllowUserToAddRows = False
        Me.dataGridViewResources.AllowUserToDeleteRows = False
        Me.dataGridViewResources.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dataGridViewResources.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewResources.DataMember = "ORDER"
        Me.dataGridViewResources.Location = New System.Drawing.Point(13, 27)
        Me.dataGridViewResources.MultiSelect = False
        Me.dataGridViewResources.Name = "dataGridViewResources"
        Me.dataGridViewResources.ReadOnly = True
        Me.dataGridViewResources.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dataGridViewResources.Size = New System.Drawing.Size(368, 206)
        Me.dataGridViewResources.TabIndex = 8
        '
        'VendorDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.labelVendorNameValue)
        Me.Controls.Add(Me.labelVendorIdValue)
        Me.Controls.Add(Me.labelVendorName)
        Me.Controls.Add(Me.labelVendorId)
        Me.Controls.Add(Me.buttonClose)
        Me.Controls.Add(Me.tabControl1)
        Me.Name = "VendorDetails"
        Me.Size = New System.Drawing.Size(500, 358)
        Me.tabControl1.ResumeLayout(False)
        Me.tabPageGeneralDetails.ResumeLayout(False)
        Me.tabPageGeneralDetails.PerformLayout()
        Me.groupBoxEmail.ResumeLayout(False)
        Me.groupBoxEmail.PerformLayout()
        Me.groupBoxTelephone.ResumeLayout(False)
        Me.groupBoxTelephone.PerformLayout()
        Me.tabPageBusinessAddress.ResumeLayout(False)
        Me.tabPageBusinessAddress.PerformLayout()
        Me.tabPageMailingAddress.ResumeLayout(False)
        Me.tabPageMailingAddress.PerformLayout()
        Me.tabPageResources.ResumeLayout(False)
        Me.tabPageResources.PerformLayout()
        CType(Me.dataGridViewResources, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents labelVendorNameValue As System.Windows.Forms.Label
    Private WithEvents labelVendorIdValue As System.Windows.Forms.Label
    Private WithEvents labelVendorName As System.Windows.Forms.Label
    Private WithEvents labelVendorId As System.Windows.Forms.Label
    Private WithEvents buttonClose As System.Windows.Forms.Button
    Private WithEvents tabControl1 As System.Windows.Forms.TabControl
    Private WithEvents tabPageGeneralDetails As System.Windows.Forms.TabPage
    Private WithEvents groupBoxEmail As System.Windows.Forms.GroupBox
    Private WithEvents textBoxEmailAddress As System.Windows.Forms.TextBox
    Private WithEvents labelEmailAddress As System.Windows.Forms.Label
    Private WithEvents textBoxVendorContactName As System.Windows.Forms.TextBox
    Private WithEvents textBoxVendorBusinessName As System.Windows.Forms.TextBox
    Private WithEvents groupBoxTelephone As System.Windows.Forms.GroupBox
    Private WithEvents textBoxMobileNumber As System.Windows.Forms.TextBox
    Private WithEvents textBoxMobileAreaCode As System.Windows.Forms.TextBox
    Private WithEvents textBoxMobileCountryCode As System.Windows.Forms.TextBox
    Private WithEvents labelMobileNumber As System.Windows.Forms.Label
    Private WithEvents labelMobileAreaCode As System.Windows.Forms.Label
    Private WithEvents labelMobilePhone As System.Windows.Forms.Label
    Private WithEvents textBoxContactNumber As System.Windows.Forms.TextBox
    Private WithEvents textBoxContactAreaCode As System.Windows.Forms.TextBox
    Private WithEvents textBoxContactCountryCode As System.Windows.Forms.TextBox
    Private WithEvents labelWorkNumber As System.Windows.Forms.Label
    Private WithEvents labelWorkAreaCode As System.Windows.Forms.Label
    Private WithEvents labelContactPhone As System.Windows.Forms.Label
    Private WithEvents textBoxOfficeNumber As System.Windows.Forms.TextBox
    Private WithEvents textBoxOfficeAreaCode As System.Windows.Forms.TextBox
    Private WithEvents textBoxOfficeCountryCode As System.Windows.Forms.TextBox
    Private WithEvents labelHomeNumber As System.Windows.Forms.Label
    Private WithEvents labelHomeAreaCode As System.Windows.Forms.Label
    Private WithEvents labelOfficePhone As System.Windows.Forms.Label
    Private WithEvents labelVendorContactName As System.Windows.Forms.Label
    Private WithEvents labelVendorBusinessName As System.Windows.Forms.Label
    Private WithEvents tabPageBusinessAddress As System.Windows.Forms.TabPage
    Private WithEvents labelPostalCode As System.Windows.Forms.Label
    Private WithEvents textBoxBPostalCode As System.Windows.Forms.TextBox
    Private WithEvents textBoxBSteetAddressLine1 As System.Windows.Forms.TextBox
    Private WithEvents labelCountry As System.Windows.Forms.Label
    Private WithEvents labelStreetAddress As System.Windows.Forms.Label
    Private WithEvents comboBoxBCountry As System.Windows.Forms.ComboBox
    Private WithEvents textBoxBSteetAddressLine2 As System.Windows.Forms.TextBox
    Private WithEvents labelRegion As System.Windows.Forms.Label
    Private WithEvents textBoxBCity As System.Windows.Forms.TextBox
    Private WithEvents textBoxBRegion As System.Windows.Forms.TextBox
    Private WithEvents labelCity As System.Windows.Forms.Label
    Private WithEvents labelState As System.Windows.Forms.Label
    Private WithEvents comboBoxBState As System.Windows.Forms.ComboBox
    Private WithEvents tabPageMailingAddress As System.Windows.Forms.TabPage
    Private WithEvents labelMPostalCode As System.Windows.Forms.Label
    Private WithEvents textBoxMPostalCode As System.Windows.Forms.TextBox
    Private WithEvents textBoxMStreetAddressLine1 As System.Windows.Forms.TextBox
    Private WithEvents labelMCountry As System.Windows.Forms.Label
    Private WithEvents labelMStreetAddress1 As System.Windows.Forms.Label
    Private WithEvents comboBoxMCountry As System.Windows.Forms.ComboBox
    Private WithEvents textBoxMStreetAddressLine2 As System.Windows.Forms.TextBox
    Private WithEvents labelMRegion As System.Windows.Forms.Label
    Private WithEvents textBoxMCity As System.Windows.Forms.TextBox
    Private WithEvents textBoxMRegion As System.Windows.Forms.TextBox
    Private WithEvents labelMCity As System.Windows.Forms.Label
    Private WithEvents labelMState As System.Windows.Forms.Label
    Private WithEvents comboBoxMState As System.Windows.Forms.ComboBox
    Private WithEvents tabPagePaymentInformation As System.Windows.Forms.TabPage
    Private WithEvents tabPageResources As System.Windows.Forms.TabPage
    Private WithEvents labelListedResources As System.Windows.Forms.Label
    Private WithEvents buttonNew As System.Windows.Forms.Button
    Private WithEvents buttonOpenResource As System.Windows.Forms.Button
    Private WithEvents dataGridViewResources As System.Windows.Forms.DataGridView

End Class
