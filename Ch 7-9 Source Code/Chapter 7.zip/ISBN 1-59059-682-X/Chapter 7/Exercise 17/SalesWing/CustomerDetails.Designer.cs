namespace com.icarustravel.enterprise31.SalesWing
{
    partial class CustomerDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageGeneralDetails = new System.Windows.Forms.TabPage();
            this.groupBoxEmail = new System.Windows.Forms.GroupBox();
            this.textBoxEmailAddress = new System.Windows.Forms.TextBox();
            this.customerDSCustomerData = new com.icarustravel.enterprise31.Customer.CustomerDS();
            this.labelEmailAddress = new System.Windows.Forms.Label();
            this.textBoxCustomerGivenName = new System.Windows.Forms.TextBox();
            this.textBoxCustomerFamilyName = new System.Windows.Forms.TextBox();
            this.groupBoxTelephone = new System.Windows.Forms.GroupBox();
            this.textBoxMobileNumber = new System.Windows.Forms.TextBox();
            this.textBoxMobileAreaCode = new System.Windows.Forms.TextBox();
            this.textBoxMobileCountryCode = new System.Windows.Forms.TextBox();
            this.labelMobileNumber = new System.Windows.Forms.Label();
            this.labelMobileAreaCode = new System.Windows.Forms.Label();
            this.labelMobilePhone = new System.Windows.Forms.Label();
            this.textBoxWorkNumber = new System.Windows.Forms.TextBox();
            this.textBoxWorkAreaCode = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.labelWorkNumber = new System.Windows.Forms.Label();
            this.labelWorkAreaCode = new System.Windows.Forms.Label();
            this.labelWorkPhone = new System.Windows.Forms.Label();
            this.textBoxHomeNumber = new System.Windows.Forms.TextBox();
            this.textBoxHomeAreaCode = new System.Windows.Forms.TextBox();
            this.textBoxHomeCountryCode = new System.Windows.Forms.TextBox();
            this.labelHomeNumber = new System.Windows.Forms.Label();
            this.labelHomeAreaCode = new System.Windows.Forms.Label();
            this.labelHomePhone = new System.Windows.Forms.Label();
            this.labelCustomerGivenName = new System.Windows.Forms.Label();
            this.labelCustomerFamilyName = new System.Windows.Forms.Label();
            this.tabPageResidenceAddress = new System.Windows.Forms.TabPage();
            this.labelPostalCode = new System.Windows.Forms.Label();
            this.textBoxRPostalCode = new System.Windows.Forms.TextBox();
            this.textBoxRSteetAddressLine1 = new System.Windows.Forms.TextBox();
            this.labelCountry = new System.Windows.Forms.Label();
            this.labelStreetAddress = new System.Windows.Forms.Label();
            this.comboBoxRCountry = new System.Windows.Forms.ComboBox();
            this.textBoxRSteetAddressLine2 = new System.Windows.Forms.TextBox();
            this.labelRegion = new System.Windows.Forms.Label();
            this.textBoxRCity = new System.Windows.Forms.TextBox();
            this.textBoxRRegion = new System.Windows.Forms.TextBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelState = new System.Windows.Forms.Label();
            this.comboBoxRState = new System.Windows.Forms.ComboBox();
            this.tabPageCorrespondenceAddress = new System.Windows.Forms.TabPage();
            this.labelCPostalCode = new System.Windows.Forms.Label();
            this.textBoxCPostalCode = new System.Windows.Forms.TextBox();
            this.textBoxCStreetAddressLine1 = new System.Windows.Forms.TextBox();
            this.labelCCountry = new System.Windows.Forms.Label();
            this.labelCStreetAddress1 = new System.Windows.Forms.Label();
            this.comboBoxCCountry = new System.Windows.Forms.ComboBox();
            this.textBoxCStreetAddressLine2 = new System.Windows.Forms.TextBox();
            this.labelCRegion = new System.Windows.Forms.Label();
            this.textBoxCCity = new System.Windows.Forms.TextBox();
            this.textBoxCRegion = new System.Windows.Forms.TextBox();
            this.labelCCity = new System.Windows.Forms.Label();
            this.labelCState = new System.Windows.Forms.Label();
            this.comboBoxCState = new System.Windows.Forms.ComboBox();
            this.tabPageBillingInformation = new System.Windows.Forms.TabPage();
            this.labelPreferredPaymentMethod = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.labelExpiryDateYear = new System.Windows.Forms.Label();
            this.labelExpiryDateMonth = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.labelNameOnCreditCard = new System.Windows.Forms.Label();
            this.labelCreditCardType = new System.Windows.Forms.Label();
            this.labelCreditCardNumber = new System.Windows.Forms.Label();
            this.tabPageOrders = new System.Windows.Forms.TabPage();
            this.labelExistingOrders = new System.Windows.Forms.Label();
            this.buttonNew = new System.Windows.Forms.Button();
            this.buttonOpenOrder = new System.Windows.Forms.Button();
            this.dataGridViewOrders = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRDERDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonClose = new System.Windows.Forms.Button();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.labelCustomerId = new System.Windows.Forms.Label();
            this.labelCustomerNameValue = new System.Windows.Forms.Label();
            this.labelCustomerIdValue = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageGeneralDetails.SuspendLayout();
            this.groupBoxEmail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerDSCustomerData)).BeginInit();
            this.groupBoxTelephone.SuspendLayout();
            this.tabPageResidenceAddress.SuspendLayout();
            this.tabPageCorrespondenceAddress.SuspendLayout();
            this.tabPageBillingInformation.SuspendLayout();
            this.tabPageOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPageGeneralDetails);
            this.tabControl1.Controls.Add(this.tabPageResidenceAddress);
            this.tabControl1.Controls.Add(this.tabPageCorrespondenceAddress);
            this.tabControl1.Controls.Add(this.tabPageBillingInformation);
            this.tabControl1.Controls.Add(this.tabPageOrders);
            this.tabControl1.Location = new System.Drawing.Point(3, 52);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(494, 267);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageGeneralDetails
            // 
            this.tabPageGeneralDetails.Controls.Add(this.groupBoxEmail);
            this.tabPageGeneralDetails.Controls.Add(this.textBoxCustomerGivenName);
            this.tabPageGeneralDetails.Controls.Add(this.textBoxCustomerFamilyName);
            this.tabPageGeneralDetails.Controls.Add(this.groupBoxTelephone);
            this.tabPageGeneralDetails.Controls.Add(this.labelCustomerGivenName);
            this.tabPageGeneralDetails.Controls.Add(this.labelCustomerFamilyName);
            this.tabPageGeneralDetails.Location = new System.Drawing.Point(4, 4);
            this.tabPageGeneralDetails.Name = "tabPageGeneralDetails";
            this.tabPageGeneralDetails.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGeneralDetails.Size = new System.Drawing.Size(486, 241);
            this.tabPageGeneralDetails.TabIndex = 0;
            this.tabPageGeneralDetails.Text = "General Details";
            this.tabPageGeneralDetails.UseVisualStyleBackColor = true;
            // 
            // groupBoxEmail
            // 
            this.groupBoxEmail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxEmail.Controls.Add(this.textBoxEmailAddress);
            this.groupBoxEmail.Controls.Add(this.labelEmailAddress);
            this.groupBoxEmail.Location = new System.Drawing.Point(16, 178);
            this.groupBoxEmail.Name = "groupBoxEmail";
            this.groupBoxEmail.Size = new System.Drawing.Size(458, 54);
            this.groupBoxEmail.TabIndex = 18;
            this.groupBoxEmail.TabStop = false;
            this.groupBoxEmail.Text = "Email";
            // 
            // textBoxEmailAddress
            // 
            this.textBoxEmailAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxEmailAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.EMAILADDRESS", true));
            this.textBoxEmailAddress.Location = new System.Drawing.Point(122, 18);
            this.textBoxEmailAddress.Name = "textBoxEmailAddress";
            this.textBoxEmailAddress.Size = new System.Drawing.Size(321, 20);
            this.textBoxEmailAddress.TabIndex = 5;
            // 
            // customerDSCustomerData
            // 
            this.customerDSCustomerData.DataSetName = "CustomerDS";
            this.customerDSCustomerData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // labelEmailAddress
            // 
            this.labelEmailAddress.AutoSize = true;
            this.labelEmailAddress.Location = new System.Drawing.Point(10, 21);
            this.labelEmailAddress.Name = "labelEmailAddress";
            this.labelEmailAddress.Size = new System.Drawing.Size(72, 13);
            this.labelEmailAddress.TabIndex = 2;
            this.labelEmailAddress.Text = "Email address";
            // 
            // textBoxCustomerGivenName
            // 
            this.textBoxCustomerGivenName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCustomerGivenName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.GIVENNAME", true));
            this.textBoxCustomerGivenName.Location = new System.Drawing.Point(138, 37);
            this.textBoxCustomerGivenName.Name = "textBoxCustomerGivenName";
            this.textBoxCustomerGivenName.Size = new System.Drawing.Size(321, 20);
            this.textBoxCustomerGivenName.TabIndex = 17;
            // 
            // textBoxCustomerFamilyName
            // 
            this.textBoxCustomerFamilyName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCustomerFamilyName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.FAMILYNAME", true));
            this.textBoxCustomerFamilyName.Location = new System.Drawing.Point(138, 11);
            this.textBoxCustomerFamilyName.Name = "textBoxCustomerFamilyName";
            this.textBoxCustomerFamilyName.Size = new System.Drawing.Size(321, 20);
            this.textBoxCustomerFamilyName.TabIndex = 16;
            // 
            // groupBoxTelephone
            // 
            this.groupBoxTelephone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxTelephone.Controls.Add(this.textBoxMobileNumber);
            this.groupBoxTelephone.Controls.Add(this.textBoxMobileAreaCode);
            this.groupBoxTelephone.Controls.Add(this.textBoxMobileCountryCode);
            this.groupBoxTelephone.Controls.Add(this.labelMobileNumber);
            this.groupBoxTelephone.Controls.Add(this.labelMobileAreaCode);
            this.groupBoxTelephone.Controls.Add(this.labelMobilePhone);
            this.groupBoxTelephone.Controls.Add(this.textBoxWorkNumber);
            this.groupBoxTelephone.Controls.Add(this.textBoxWorkAreaCode);
            this.groupBoxTelephone.Controls.Add(this.textBox3);
            this.groupBoxTelephone.Controls.Add(this.labelWorkNumber);
            this.groupBoxTelephone.Controls.Add(this.labelWorkAreaCode);
            this.groupBoxTelephone.Controls.Add(this.labelWorkPhone);
            this.groupBoxTelephone.Controls.Add(this.textBoxHomeNumber);
            this.groupBoxTelephone.Controls.Add(this.textBoxHomeAreaCode);
            this.groupBoxTelephone.Controls.Add(this.textBoxHomeCountryCode);
            this.groupBoxTelephone.Controls.Add(this.labelHomeNumber);
            this.groupBoxTelephone.Controls.Add(this.labelHomeAreaCode);
            this.groupBoxTelephone.Controls.Add(this.labelHomePhone);
            this.groupBoxTelephone.Location = new System.Drawing.Point(16, 67);
            this.groupBoxTelephone.Name = "groupBoxTelephone";
            this.groupBoxTelephone.Size = new System.Drawing.Size(458, 100);
            this.groupBoxTelephone.TabIndex = 15;
            this.groupBoxTelephone.TabStop = false;
            this.groupBoxTelephone.Text = "Telephone";
            // 
            // textBoxMobileNumber
            // 
            this.textBoxMobileNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMobileNumber.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.MOBILENUMBER", true));
            this.textBoxMobileNumber.Location = new System.Drawing.Point(368, 69);
            this.textBoxMobileNumber.Name = "textBoxMobileNumber";
            this.textBoxMobileNumber.Size = new System.Drawing.Size(75, 20);
            this.textBoxMobileNumber.TabIndex = 19;
            // 
            // textBoxMobileAreaCode
            // 
            this.textBoxMobileAreaCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.MOBILEAREACODE", true));
            this.textBoxMobileAreaCode.Location = new System.Drawing.Point(237, 69);
            this.textBoxMobileAreaCode.Name = "textBoxMobileAreaCode";
            this.textBoxMobileAreaCode.Size = new System.Drawing.Size(75, 20);
            this.textBoxMobileAreaCode.TabIndex = 18;
            // 
            // textBoxMobileCountryCode
            // 
            this.textBoxMobileCountryCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.MOBILECOUNTRYCODE", true));
            this.textBoxMobileCountryCode.Location = new System.Drawing.Point(122, 69);
            this.textBoxMobileCountryCode.Name = "textBoxMobileCountryCode";
            this.textBoxMobileCountryCode.Size = new System.Drawing.Size(46, 20);
            this.textBoxMobileCountryCode.TabIndex = 17;
            // 
            // labelMobileNumber
            // 
            this.labelMobileNumber.AutoSize = true;
            this.labelMobileNumber.Location = new System.Drawing.Point(318, 72);
            this.labelMobileNumber.Name = "labelMobileNumber";
            this.labelMobileNumber.Size = new System.Drawing.Size(44, 13);
            this.labelMobileNumber.TabIndex = 16;
            this.labelMobileNumber.Text = "Number";
            // 
            // labelMobileAreaCode
            // 
            this.labelMobileAreaCode.AutoSize = true;
            this.labelMobileAreaCode.Location = new System.Drawing.Point(174, 72);
            this.labelMobileAreaCode.Name = "labelMobileAreaCode";
            this.labelMobileAreaCode.Size = new System.Drawing.Size(57, 13);
            this.labelMobileAreaCode.TabIndex = 15;
            this.labelMobileAreaCode.Text = "Area Code";
            // 
            // labelMobilePhone
            // 
            this.labelMobilePhone.AutoSize = true;
            this.labelMobilePhone.Location = new System.Drawing.Point(10, 72);
            this.labelMobilePhone.Name = "labelMobilePhone";
            this.labelMobilePhone.Size = new System.Drawing.Size(108, 13);
            this.labelMobilePhone.TabIndex = 14;
            this.labelMobilePhone.Text = "Mobile: Country Code";
            // 
            // textBoxWorkNumber
            // 
            this.textBoxWorkNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxWorkNumber.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.WORKNUMBER", true));
            this.textBoxWorkNumber.Location = new System.Drawing.Point(368, 43);
            this.textBoxWorkNumber.Name = "textBoxWorkNumber";
            this.textBoxWorkNumber.Size = new System.Drawing.Size(75, 20);
            this.textBoxWorkNumber.TabIndex = 13;
            // 
            // textBoxWorkAreaCode
            // 
            this.textBoxWorkAreaCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.WORKAREACODE", true));
            this.textBoxWorkAreaCode.Location = new System.Drawing.Point(237, 43);
            this.textBoxWorkAreaCode.Name = "textBoxWorkAreaCode";
            this.textBoxWorkAreaCode.Size = new System.Drawing.Size(75, 20);
            this.textBoxWorkAreaCode.TabIndex = 12;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.WORKCOUNTRYCODE", true));
            this.textBox3.Location = new System.Drawing.Point(122, 43);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(46, 20);
            this.textBox3.TabIndex = 11;
            // 
            // labelWorkNumber
            // 
            this.labelWorkNumber.AutoSize = true;
            this.labelWorkNumber.Location = new System.Drawing.Point(318, 46);
            this.labelWorkNumber.Name = "labelWorkNumber";
            this.labelWorkNumber.Size = new System.Drawing.Size(44, 13);
            this.labelWorkNumber.TabIndex = 10;
            this.labelWorkNumber.Text = "Number";
            // 
            // labelWorkAreaCode
            // 
            this.labelWorkAreaCode.AutoSize = true;
            this.labelWorkAreaCode.Location = new System.Drawing.Point(174, 46);
            this.labelWorkAreaCode.Name = "labelWorkAreaCode";
            this.labelWorkAreaCode.Size = new System.Drawing.Size(57, 13);
            this.labelWorkAreaCode.TabIndex = 9;
            this.labelWorkAreaCode.Text = "Area Code";
            // 
            // labelWorkPhone
            // 
            this.labelWorkPhone.AutoSize = true;
            this.labelWorkPhone.Location = new System.Drawing.Point(10, 46);
            this.labelWorkPhone.Name = "labelWorkPhone";
            this.labelWorkPhone.Size = new System.Drawing.Size(103, 13);
            this.labelWorkPhone.TabIndex = 8;
            this.labelWorkPhone.Text = "Work: Country Code";
            // 
            // textBoxHomeNumber
            // 
            this.textBoxHomeNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxHomeNumber.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.HOMENUMBER", true));
            this.textBoxHomeNumber.Location = new System.Drawing.Point(368, 18);
            this.textBoxHomeNumber.Name = "textBoxHomeNumber";
            this.textBoxHomeNumber.Size = new System.Drawing.Size(75, 20);
            this.textBoxHomeNumber.TabIndex = 7;
            // 
            // textBoxHomeAreaCode
            // 
            this.textBoxHomeAreaCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.HOMEAREACODE", true));
            this.textBoxHomeAreaCode.Location = new System.Drawing.Point(237, 18);
            this.textBoxHomeAreaCode.Name = "textBoxHomeAreaCode";
            this.textBoxHomeAreaCode.Size = new System.Drawing.Size(75, 20);
            this.textBoxHomeAreaCode.TabIndex = 6;
            // 
            // textBoxHomeCountryCode
            // 
            this.textBoxHomeCountryCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.HOMECOUNTRYCODE", true));
            this.textBoxHomeCountryCode.Location = new System.Drawing.Point(122, 18);
            this.textBoxHomeCountryCode.Name = "textBoxHomeCountryCode";
            this.textBoxHomeCountryCode.Size = new System.Drawing.Size(46, 20);
            this.textBoxHomeCountryCode.TabIndex = 5;
            // 
            // labelHomeNumber
            // 
            this.labelHomeNumber.AutoSize = true;
            this.labelHomeNumber.Location = new System.Drawing.Point(318, 21);
            this.labelHomeNumber.Name = "labelHomeNumber";
            this.labelHomeNumber.Size = new System.Drawing.Size(44, 13);
            this.labelHomeNumber.TabIndex = 4;
            this.labelHomeNumber.Text = "Number";
            // 
            // labelHomeAreaCode
            // 
            this.labelHomeAreaCode.AutoSize = true;
            this.labelHomeAreaCode.Location = new System.Drawing.Point(174, 21);
            this.labelHomeAreaCode.Name = "labelHomeAreaCode";
            this.labelHomeAreaCode.Size = new System.Drawing.Size(57, 13);
            this.labelHomeAreaCode.TabIndex = 3;
            this.labelHomeAreaCode.Text = "Area Code";
            // 
            // labelHomePhone
            // 
            this.labelHomePhone.AutoSize = true;
            this.labelHomePhone.Location = new System.Drawing.Point(10, 21);
            this.labelHomePhone.Name = "labelHomePhone";
            this.labelHomePhone.Size = new System.Drawing.Size(105, 13);
            this.labelHomePhone.TabIndex = 2;
            this.labelHomePhone.Text = "Home: Country Code";
            // 
            // labelCustomerGivenName
            // 
            this.labelCustomerGivenName.AutoSize = true;
            this.labelCustomerGivenName.Location = new System.Drawing.Point(13, 40);
            this.labelCustomerGivenName.Name = "labelCustomerGivenName";
            this.labelCustomerGivenName.Size = new System.Drawing.Size(113, 13);
            this.labelCustomerGivenName.TabIndex = 14;
            this.labelCustomerGivenName.Text = "Customer Given Name";
            // 
            // labelCustomerFamilyName
            // 
            this.labelCustomerFamilyName.AutoSize = true;
            this.labelCustomerFamilyName.Location = new System.Drawing.Point(13, 14);
            this.labelCustomerFamilyName.Name = "labelCustomerFamilyName";
            this.labelCustomerFamilyName.Size = new System.Drawing.Size(114, 13);
            this.labelCustomerFamilyName.TabIndex = 13;
            this.labelCustomerFamilyName.Text = "Customer Family Name";
            // 
            // tabPageResidenceAddress
            // 
            this.tabPageResidenceAddress.Controls.Add(this.labelPostalCode);
            this.tabPageResidenceAddress.Controls.Add(this.textBoxRPostalCode);
            this.tabPageResidenceAddress.Controls.Add(this.textBoxRSteetAddressLine1);
            this.tabPageResidenceAddress.Controls.Add(this.labelCountry);
            this.tabPageResidenceAddress.Controls.Add(this.labelStreetAddress);
            this.tabPageResidenceAddress.Controls.Add(this.comboBoxRCountry);
            this.tabPageResidenceAddress.Controls.Add(this.textBoxRSteetAddressLine2);
            this.tabPageResidenceAddress.Controls.Add(this.labelRegion);
            this.tabPageResidenceAddress.Controls.Add(this.textBoxRCity);
            this.tabPageResidenceAddress.Controls.Add(this.textBoxRRegion);
            this.tabPageResidenceAddress.Controls.Add(this.labelCity);
            this.tabPageResidenceAddress.Controls.Add(this.labelState);
            this.tabPageResidenceAddress.Controls.Add(this.comboBoxRState);
            this.tabPageResidenceAddress.Location = new System.Drawing.Point(4, 4);
            this.tabPageResidenceAddress.Name = "tabPageResidenceAddress";
            this.tabPageResidenceAddress.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageResidenceAddress.Size = new System.Drawing.Size(486, 241);
            this.tabPageResidenceAddress.TabIndex = 1;
            this.tabPageResidenceAddress.Text = "Residence Address";
            this.tabPageResidenceAddress.UseVisualStyleBackColor = true;
            // 
            // labelPostalCode
            // 
            this.labelPostalCode.AutoSize = true;
            this.labelPostalCode.Location = new System.Drawing.Point(10, 181);
            this.labelPostalCode.Name = "labelPostalCode";
            this.labelPostalCode.Size = new System.Drawing.Size(64, 13);
            this.labelPostalCode.TabIndex = 38;
            this.labelPostalCode.Text = "Postal Code";
            // 
            // textBoxRPostalCode
            // 
            this.textBoxRPostalCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRPostalCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.RESIDENCEPOSTALCODE", true));
            this.textBoxRPostalCode.Location = new System.Drawing.Point(129, 178);
            this.textBoxRPostalCode.Name = "textBoxRPostalCode";
            this.textBoxRPostalCode.Size = new System.Drawing.Size(175, 20);
            this.textBoxRPostalCode.TabIndex = 37;
            // 
            // textBoxRSteetAddressLine1
            // 
            this.textBoxRSteetAddressLine1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRSteetAddressLine1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.RESIDENCESTREETADDRESSLINE1", true));
            this.textBoxRSteetAddressLine1.Location = new System.Drawing.Point(129, 7);
            this.textBoxRSteetAddressLine1.Name = "textBoxRSteetAddressLine1";
            this.textBoxRSteetAddressLine1.Size = new System.Drawing.Size(348, 20);
            this.textBoxRSteetAddressLine1.TabIndex = 27;
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Location = new System.Drawing.Point(9, 215);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(43, 13);
            this.labelCountry.TabIndex = 36;
            this.labelCountry.Text = "Country";
            // 
            // labelStreetAddress
            // 
            this.labelStreetAddress.AutoSize = true;
            this.labelStreetAddress.Location = new System.Drawing.Point(9, 10);
            this.labelStreetAddress.Name = "labelStreetAddress";
            this.labelStreetAddress.Size = new System.Drawing.Size(76, 13);
            this.labelStreetAddress.TabIndex = 26;
            this.labelStreetAddress.Text = "Street Address";
            // 
            // comboBoxRCountry
            // 
            this.comboBoxRCountry.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxRCountry.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customerDSCustomerData, "CUSTOMER.RESIDENCECOUNTRYID", true));
            this.comboBoxRCountry.DataSource = this.customerDSCustomerData;
            this.comboBoxRCountry.DisplayMember = "COUNTRIES.NAME";
            this.comboBoxRCountry.FormattingEnabled = true;
            this.comboBoxRCountry.Location = new System.Drawing.Point(129, 212);
            this.comboBoxRCountry.Name = "comboBoxRCountry";
            this.comboBoxRCountry.Size = new System.Drawing.Size(175, 21);
            this.comboBoxRCountry.TabIndex = 35;
            this.comboBoxRCountry.ValueMember = "COUNTRIES.ID";
            // 
            // textBoxRSteetAddressLine2
            // 
            this.textBoxRSteetAddressLine2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRSteetAddressLine2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.RESIDENCESTREETADDRESSLINE2", true));
            this.textBoxRSteetAddressLine2.Location = new System.Drawing.Point(129, 41);
            this.textBoxRSteetAddressLine2.Name = "textBoxRSteetAddressLine2";
            this.textBoxRSteetAddressLine2.Size = new System.Drawing.Size(348, 20);
            this.textBoxRSteetAddressLine2.TabIndex = 28;
            // 
            // labelRegion
            // 
            this.labelRegion.AutoSize = true;
            this.labelRegion.Location = new System.Drawing.Point(10, 112);
            this.labelRegion.Name = "labelRegion";
            this.labelRegion.Size = new System.Drawing.Size(113, 13);
            this.labelRegion.TabIndex = 34;
            this.labelRegion.Text = "Region (Province etc.)";
            // 
            // textBoxRCity
            // 
            this.textBoxRCity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.RESIDENCECITYNAME", true));
            this.textBoxRCity.Location = new System.Drawing.Point(129, 75);
            this.textBoxRCity.Name = "textBoxRCity";
            this.textBoxRCity.Size = new System.Drawing.Size(348, 20);
            this.textBoxRCity.TabIndex = 29;
            // 
            // textBoxRRegion
            // 
            this.textBoxRRegion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRRegion.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.RESIDENCEREGION", true));
            this.textBoxRRegion.Location = new System.Drawing.Point(129, 109);
            this.textBoxRRegion.Name = "textBoxRRegion";
            this.textBoxRRegion.Size = new System.Drawing.Size(348, 20);
            this.textBoxRRegion.TabIndex = 33;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(10, 78);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(24, 13);
            this.labelCity.TabIndex = 30;
            this.labelCity.Text = "City";
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(9, 146);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(78, 13);
            this.labelState.TabIndex = 32;
            this.labelState.Text = "State (US only)";
            // 
            // comboBoxRState
            // 
            this.comboBoxRState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxRState.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customerDSCustomerData, "CUSTOMER.RESIDENCESTATEID", true));
            this.comboBoxRState.DataSource = this.customerDSCustomerData;
            this.comboBoxRState.DisplayMember = "STATES.NAME";
            this.comboBoxRState.FormattingEnabled = true;
            this.comboBoxRState.Location = new System.Drawing.Point(129, 143);
            this.comboBoxRState.Name = "comboBoxRState";
            this.comboBoxRState.Size = new System.Drawing.Size(175, 21);
            this.comboBoxRState.TabIndex = 31;
            this.comboBoxRState.ValueMember = "STATES.ID";
            // 
            // tabPageCorrespondenceAddress
            // 
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCPostalCode);
            this.tabPageCorrespondenceAddress.Controls.Add(this.textBoxCPostalCode);
            this.tabPageCorrespondenceAddress.Controls.Add(this.textBoxCStreetAddressLine1);
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCCountry);
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCStreetAddress1);
            this.tabPageCorrespondenceAddress.Controls.Add(this.comboBoxCCountry);
            this.tabPageCorrespondenceAddress.Controls.Add(this.textBoxCStreetAddressLine2);
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCRegion);
            this.tabPageCorrespondenceAddress.Controls.Add(this.textBoxCCity);
            this.tabPageCorrespondenceAddress.Controls.Add(this.textBoxCRegion);
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCCity);
            this.tabPageCorrespondenceAddress.Controls.Add(this.labelCState);
            this.tabPageCorrespondenceAddress.Controls.Add(this.comboBoxCState);
            this.tabPageCorrespondenceAddress.Location = new System.Drawing.Point(4, 4);
            this.tabPageCorrespondenceAddress.Name = "tabPageCorrespondenceAddress";
            this.tabPageCorrespondenceAddress.Size = new System.Drawing.Size(486, 241);
            this.tabPageCorrespondenceAddress.TabIndex = 2;
            this.tabPageCorrespondenceAddress.Text = "Correspondence Address";
            this.tabPageCorrespondenceAddress.UseVisualStyleBackColor = true;
            // 
            // labelCPostalCode
            // 
            this.labelCPostalCode.AutoSize = true;
            this.labelCPostalCode.Location = new System.Drawing.Point(10, 181);
            this.labelCPostalCode.Name = "labelCPostalCode";
            this.labelCPostalCode.Size = new System.Drawing.Size(64, 13);
            this.labelCPostalCode.TabIndex = 51;
            this.labelCPostalCode.Text = "Postal Code";
            // 
            // textBoxCPostalCode
            // 
            this.textBoxCPostalCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCPostalCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCEPOSTALCODE", true));
            this.textBoxCPostalCode.Location = new System.Drawing.Point(129, 178);
            this.textBoxCPostalCode.Name = "textBoxCPostalCode";
            this.textBoxCPostalCode.Size = new System.Drawing.Size(175, 20);
            this.textBoxCPostalCode.TabIndex = 50;
            // 
            // textBoxCStreetAddressLine1
            // 
            this.textBoxCStreetAddressLine1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCStreetAddressLine1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCESTREETADDRESSLINE1", true));
            this.textBoxCStreetAddressLine1.Location = new System.Drawing.Point(129, 7);
            this.textBoxCStreetAddressLine1.Name = "textBoxCStreetAddressLine1";
            this.textBoxCStreetAddressLine1.Size = new System.Drawing.Size(348, 20);
            this.textBoxCStreetAddressLine1.TabIndex = 40;
            // 
            // labelCCountry
            // 
            this.labelCCountry.AutoSize = true;
            this.labelCCountry.Location = new System.Drawing.Point(9, 215);
            this.labelCCountry.Name = "labelCCountry";
            this.labelCCountry.Size = new System.Drawing.Size(43, 13);
            this.labelCCountry.TabIndex = 49;
            this.labelCCountry.Text = "Country";
            // 
            // labelCStreetAddress1
            // 
            this.labelCStreetAddress1.AutoSize = true;
            this.labelCStreetAddress1.Location = new System.Drawing.Point(9, 10);
            this.labelCStreetAddress1.Name = "labelCStreetAddress1";
            this.labelCStreetAddress1.Size = new System.Drawing.Size(76, 13);
            this.labelCStreetAddress1.TabIndex = 39;
            this.labelCStreetAddress1.Text = "Street Address";
            // 
            // comboBoxCCountry
            // 
            this.comboBoxCCountry.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxCCountry.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCECOUNTRYID", true));
            this.comboBoxCCountry.DataSource = this.customerDSCustomerData;
            this.comboBoxCCountry.DisplayMember = "COUNTRIES.NAME";
            this.comboBoxCCountry.FormattingEnabled = true;
            this.comboBoxCCountry.Location = new System.Drawing.Point(129, 212);
            this.comboBoxCCountry.Name = "comboBoxCCountry";
            this.comboBoxCCountry.Size = new System.Drawing.Size(175, 21);
            this.comboBoxCCountry.TabIndex = 48;
            this.comboBoxCCountry.ValueMember = "COUNTRIES.ID";
            // 
            // textBoxCStreetAddressLine2
            // 
            this.textBoxCStreetAddressLine2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCStreetAddressLine2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCESTREETADDRESSLINE2", true));
            this.textBoxCStreetAddressLine2.Location = new System.Drawing.Point(129, 41);
            this.textBoxCStreetAddressLine2.Name = "textBoxCStreetAddressLine2";
            this.textBoxCStreetAddressLine2.Size = new System.Drawing.Size(348, 20);
            this.textBoxCStreetAddressLine2.TabIndex = 41;
            // 
            // labelCRegion
            // 
            this.labelCRegion.AutoSize = true;
            this.labelCRegion.Location = new System.Drawing.Point(10, 112);
            this.labelCRegion.Name = "labelCRegion";
            this.labelCRegion.Size = new System.Drawing.Size(113, 13);
            this.labelCRegion.TabIndex = 47;
            this.labelCRegion.Text = "Region (Province etc.)";
            // 
            // textBoxCCity
            // 
            this.textBoxCCity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCECITYNAME", true));
            this.textBoxCCity.Location = new System.Drawing.Point(129, 75);
            this.textBoxCCity.Name = "textBoxCCity";
            this.textBoxCCity.Size = new System.Drawing.Size(348, 20);
            this.textBoxCCity.TabIndex = 42;
            // 
            // textBoxCRegion
            // 
            this.textBoxCRegion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCRegion.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCEREGION", true));
            this.textBoxCRegion.Location = new System.Drawing.Point(129, 109);
            this.textBoxCRegion.Name = "textBoxCRegion";
            this.textBoxCRegion.Size = new System.Drawing.Size(348, 20);
            this.textBoxCRegion.TabIndex = 46;
            // 
            // labelCCity
            // 
            this.labelCCity.AutoSize = true;
            this.labelCCity.Location = new System.Drawing.Point(10, 78);
            this.labelCCity.Name = "labelCCity";
            this.labelCCity.Size = new System.Drawing.Size(24, 13);
            this.labelCCity.TabIndex = 43;
            this.labelCCity.Text = "City";
            // 
            // labelCState
            // 
            this.labelCState.AutoSize = true;
            this.labelCState.Location = new System.Drawing.Point(9, 146);
            this.labelCState.Name = "labelCState";
            this.labelCState.Size = new System.Drawing.Size(78, 13);
            this.labelCState.TabIndex = 45;
            this.labelCState.Text = "State (US only)";
            // 
            // comboBoxCState
            // 
            this.comboBoxCState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxCState.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.customerDSCustomerData, "CUSTOMER.CORRESPONDENCESTATEID", true));
            this.comboBoxCState.DataSource = this.customerDSCustomerData;
            this.comboBoxCState.DisplayMember = "STATES.NAME";
            this.comboBoxCState.FormattingEnabled = true;
            this.comboBoxCState.Location = new System.Drawing.Point(129, 143);
            this.comboBoxCState.Name = "comboBoxCState";
            this.comboBoxCState.Size = new System.Drawing.Size(175, 21);
            this.comboBoxCState.TabIndex = 44;
            this.comboBoxCState.ValueMember = "STATES.ID";
            // 
            // tabPageBillingInformation
            // 
            this.tabPageBillingInformation.Controls.Add(this.labelPreferredPaymentMethod);
            this.tabPageBillingInformation.Controls.Add(this.comboBox4);
            this.tabPageBillingInformation.Controls.Add(this.comboBox3);
            this.tabPageBillingInformation.Controls.Add(this.textBox2);
            this.tabPageBillingInformation.Controls.Add(this.textBox1);
            this.tabPageBillingInformation.Controls.Add(this.comboBox2);
            this.tabPageBillingInformation.Controls.Add(this.labelExpiryDateYear);
            this.tabPageBillingInformation.Controls.Add(this.labelExpiryDateMonth);
            this.tabPageBillingInformation.Controls.Add(this.comboBox1);
            this.tabPageBillingInformation.Controls.Add(this.labelNameOnCreditCard);
            this.tabPageBillingInformation.Controls.Add(this.labelCreditCardType);
            this.tabPageBillingInformation.Controls.Add(this.labelCreditCardNumber);
            this.tabPageBillingInformation.Location = new System.Drawing.Point(4, 4);
            this.tabPageBillingInformation.Name = "tabPageBillingInformation";
            this.tabPageBillingInformation.Size = new System.Drawing.Size(486, 241);
            this.tabPageBillingInformation.TabIndex = 3;
            this.tabPageBillingInformation.Text = "Billing Information";
            this.tabPageBillingInformation.UseVisualStyleBackColor = true;
            // 
            // labelPreferredPaymentMethod
            // 
            this.labelPreferredPaymentMethod.AutoSize = true;
            this.labelPreferredPaymentMethod.Location = new System.Drawing.Point(9, 25);
            this.labelPreferredPaymentMethod.Name = "labelPreferredPaymentMethod";
            this.labelPreferredPaymentMethod.Size = new System.Drawing.Size(133, 13);
            this.labelPreferredPaymentMethod.TabIndex = 35;
            this.labelPreferredPaymentMethod.Text = "Preferred Payment Method";
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(148, 22);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(153, 21);
            this.comboBox4.TabIndex = 34;
            // 
            // comboBox3
            // 
            this.comboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(148, 58);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(153, 21);
            this.comboBox3.TabIndex = 33;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox2.Location = new System.Drawing.Point(148, 95);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(331, 20);
            this.textBox2.TabIndex = 32;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(148, 132);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(332, 20);
            this.textBox1.TabIndex = 31;
            // 
            // comboBox2
            // 
            this.comboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(334, 169);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(145, 21);
            this.comboBox2.TabIndex = 30;
            // 
            // labelExpiryDateYear
            // 
            this.labelExpiryDateYear.AutoSize = true;
            this.labelExpiryDateYear.Location = new System.Drawing.Point(291, 172);
            this.labelExpiryDateYear.Name = "labelExpiryDateYear";
            this.labelExpiryDateYear.Size = new System.Drawing.Size(29, 13);
            this.labelExpiryDateYear.TabIndex = 29;
            this.labelExpiryDateYear.Text = "Year";
            // 
            // labelExpiryDateMonth
            // 
            this.labelExpiryDateMonth.AutoSize = true;
            this.labelExpiryDateMonth.Location = new System.Drawing.Point(9, 172);
            this.labelExpiryDateMonth.Name = "labelExpiryDateMonth";
            this.labelExpiryDateMonth.Size = new System.Drawing.Size(118, 13);
            this.labelExpiryDateMonth.TabIndex = 28;
            this.labelExpiryDateMonth.Text = "Expiry Date         Month";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(148, 169);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(125, 21);
            this.comboBox1.TabIndex = 27;
            // 
            // labelNameOnCreditCard
            // 
            this.labelNameOnCreditCard.AutoSize = true;
            this.labelNameOnCreditCard.Location = new System.Drawing.Point(9, 135);
            this.labelNameOnCreditCard.Name = "labelNameOnCreditCard";
            this.labelNameOnCreditCard.Size = new System.Drawing.Size(107, 13);
            this.labelNameOnCreditCard.TabIndex = 26;
            this.labelNameOnCreditCard.Text = "Name On Credit Card";
            // 
            // labelCreditCardType
            // 
            this.labelCreditCardType.AutoSize = true;
            this.labelCreditCardType.Location = new System.Drawing.Point(9, 61);
            this.labelCreditCardType.Name = "labelCreditCardType";
            this.labelCreditCardType.Size = new System.Drawing.Size(86, 13);
            this.labelCreditCardType.TabIndex = 25;
            this.labelCreditCardType.Text = "Credit Card Type";
            // 
            // labelCreditCardNumber
            // 
            this.labelCreditCardNumber.AutoSize = true;
            this.labelCreditCardNumber.Location = new System.Drawing.Point(9, 98);
            this.labelCreditCardNumber.Name = "labelCreditCardNumber";
            this.labelCreditCardNumber.Size = new System.Drawing.Size(99, 13);
            this.labelCreditCardNumber.TabIndex = 24;
            this.labelCreditCardNumber.Text = "Credit Card Number";
            // 
            // tabPageOrders
            // 
            this.tabPageOrders.Controls.Add(this.labelExistingOrders);
            this.tabPageOrders.Controls.Add(this.buttonNew);
            this.tabPageOrders.Controls.Add(this.buttonOpenOrder);
            this.tabPageOrders.Controls.Add(this.dataGridViewOrders);
            this.tabPageOrders.Location = new System.Drawing.Point(4, 4);
            this.tabPageOrders.Name = "tabPageOrders";
            this.tabPageOrders.Size = new System.Drawing.Size(486, 241);
            this.tabPageOrders.TabIndex = 4;
            this.tabPageOrders.Text = "Orders";
            this.tabPageOrders.UseVisualStyleBackColor = true;
            // 
            // labelExistingOrders
            // 
            this.labelExistingOrders.AutoSize = true;
            this.labelExistingOrders.Location = new System.Drawing.Point(13, 8);
            this.labelExistingOrders.Name = "labelExistingOrders";
            this.labelExistingOrders.Size = new System.Drawing.Size(77, 13);
            this.labelExistingOrders.TabIndex = 11;
            this.labelExistingOrders.Text = "Existing Orders";
            // 
            // buttonNew
            // 
            this.buttonNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonNew.Location = new System.Drawing.Point(399, 210);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 10;
            this.buttonNew.Text = "New ...";
            this.buttonNew.UseVisualStyleBackColor = true;
            // 
            // buttonOpenOrder
            // 
            this.buttonOpenOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenOrder.Location = new System.Drawing.Point(399, 170);
            this.buttonOpenOrder.Name = "buttonOpenOrder";
            this.buttonOpenOrder.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenOrder.TabIndex = 9;
            this.buttonOpenOrder.Text = "Open";
            this.buttonOpenOrder.UseVisualStyleBackColor = true;
            // 
            // dataGridViewOrders
            // 
            this.dataGridViewOrders.AllowUserToAddRows = false;
            this.dataGridViewOrders.AllowUserToDeleteRows = false;
            this.dataGridViewOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewOrders.AutoGenerateColumns = false;
            this.dataGridViewOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOrders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.oRDERDATEDataGridViewTextBoxColumn});
            this.dataGridViewOrders.DataMember = "ORDER";
            this.dataGridViewOrders.DataSource = this.customerDSCustomerData;
            this.dataGridViewOrders.Location = new System.Drawing.Point(13, 27);
            this.dataGridViewOrders.MultiSelect = false;
            this.dataGridViewOrders.Name = "dataGridViewOrders";
            this.dataGridViewOrders.ReadOnly = true;
            this.dataGridViewOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewOrders.Size = new System.Drawing.Size(368, 206);
            this.dataGridViewOrders.TabIndex = 8;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "Order Number";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oRDERDATEDataGridViewTextBoxColumn
            // 
            this.oRDERDATEDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.oRDERDATEDataGridViewTextBoxColumn.DataPropertyName = "ORDERDATE";
            this.oRDERDATEDataGridViewTextBoxColumn.HeaderText = "Order Date";
            this.oRDERDATEDataGridViewTextBoxColumn.Name = "oRDERDATEDataGridViewTextBoxColumn";
            this.oRDERDATEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.Location = new System.Drawing.Point(406, 327);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 11;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Location = new System.Drawing.Point(16, 32);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(82, 13);
            this.labelCustomerName.TabIndex = 13;
            this.labelCustomerName.Text = "Customer Name";
            // 
            // labelCustomerId
            // 
            this.labelCustomerId.AutoSize = true;
            this.labelCustomerId.Location = new System.Drawing.Point(17, 8);
            this.labelCustomerId.Name = "labelCustomerId";
            this.labelCustomerId.Size = new System.Drawing.Size(65, 13);
            this.labelCustomerId.TabIndex = 12;
            this.labelCustomerId.Text = "Customer ID";
            // 
            // labelCustomerNameValue
            // 
            this.labelCustomerNameValue.AutoSize = true;
            this.labelCustomerNameValue.Location = new System.Drawing.Point(123, 32);
            this.labelCustomerNameValue.Name = "labelCustomerNameValue";
            this.labelCustomerNameValue.Size = new System.Drawing.Size(0, 13);
            this.labelCustomerNameValue.TabIndex = 15;
            // 
            // labelCustomerIdValue
            // 
            this.labelCustomerIdValue.AutoSize = true;
            this.labelCustomerIdValue.Location = new System.Drawing.Point(123, 8);
            this.labelCustomerIdValue.Name = "labelCustomerIdValue";
            this.labelCustomerIdValue.Size = new System.Drawing.Size(0, 13);
            this.labelCustomerIdValue.TabIndex = 14;
            // 
            // CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labelCustomerNameValue);
            this.Controls.Add(this.labelCustomerIdValue);
            this.Controls.Add(this.labelCustomerName);
            this.Controls.Add(this.labelCustomerId);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.tabControl1);
            this.Name = "CustomerDetails";
            this.Size = new System.Drawing.Size(500, 358);
            this.tabControl1.ResumeLayout(false);
            this.tabPageGeneralDetails.ResumeLayout(false);
            this.tabPageGeneralDetails.PerformLayout();
            this.groupBoxEmail.ResumeLayout(false);
            this.groupBoxEmail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerDSCustomerData)).EndInit();
            this.groupBoxTelephone.ResumeLayout(false);
            this.groupBoxTelephone.PerformLayout();
            this.tabPageResidenceAddress.ResumeLayout(false);
            this.tabPageResidenceAddress.PerformLayout();
            this.tabPageCorrespondenceAddress.ResumeLayout(false);
            this.tabPageCorrespondenceAddress.PerformLayout();
            this.tabPageBillingInformation.ResumeLayout(false);
            this.tabPageBillingInformation.PerformLayout();
            this.tabPageOrders.ResumeLayout(false);
            this.tabPageOrders.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageGeneralDetails;
        private System.Windows.Forms.TabPage tabPageResidenceAddress;
        private System.Windows.Forms.TabPage tabPageCorrespondenceAddress;
        private System.Windows.Forms.TabPage tabPageBillingInformation;
        private System.Windows.Forms.TabPage tabPageOrders;
        private System.Windows.Forms.GroupBox groupBoxEmail;
        private System.Windows.Forms.TextBox textBoxEmailAddress;
        private System.Windows.Forms.Label labelEmailAddress;
        private System.Windows.Forms.TextBox textBoxCustomerGivenName;
        private System.Windows.Forms.TextBox textBoxCustomerFamilyName;
        private System.Windows.Forms.GroupBox groupBoxTelephone;
        private System.Windows.Forms.TextBox textBoxMobileNumber;
        private System.Windows.Forms.TextBox textBoxMobileAreaCode;
        private System.Windows.Forms.TextBox textBoxMobileCountryCode;
        private System.Windows.Forms.Label labelMobileNumber;
        private System.Windows.Forms.Label labelMobileAreaCode;
        private System.Windows.Forms.Label labelMobilePhone;
        private System.Windows.Forms.TextBox textBoxWorkNumber;
        private System.Windows.Forms.TextBox textBoxWorkAreaCode;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label labelWorkNumber;
        private System.Windows.Forms.Label labelWorkAreaCode;
        private System.Windows.Forms.Label labelWorkPhone;
        private System.Windows.Forms.TextBox textBoxHomeNumber;
        private System.Windows.Forms.TextBox textBoxHomeAreaCode;
        private System.Windows.Forms.TextBox textBoxHomeCountryCode;
        private System.Windows.Forms.Label labelHomeNumber;
        private System.Windows.Forms.Label labelHomeAreaCode;
        private System.Windows.Forms.Label labelHomePhone;
        private System.Windows.Forms.Label labelCustomerGivenName;
        private System.Windows.Forms.Label labelCustomerFamilyName;
        private System.Windows.Forms.Label labelPostalCode;
        private System.Windows.Forms.TextBox textBoxRPostalCode;
        private System.Windows.Forms.TextBox textBoxRSteetAddressLine1;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.Label labelStreetAddress;
        private System.Windows.Forms.ComboBox comboBoxRCountry;
        private System.Windows.Forms.TextBox textBoxRSteetAddressLine2;
        private System.Windows.Forms.Label labelRegion;
        private System.Windows.Forms.TextBox textBoxRCity;
        private System.Windows.Forms.TextBox textBoxRRegion;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.ComboBox comboBoxRState;
        private System.Windows.Forms.Label labelCPostalCode;
        private System.Windows.Forms.TextBox textBoxCPostalCode;
        private System.Windows.Forms.TextBox textBoxCStreetAddressLine1;
        private System.Windows.Forms.Label labelCCountry;
        private System.Windows.Forms.Label labelCStreetAddress1;
        private System.Windows.Forms.ComboBox comboBoxCCountry;
        private System.Windows.Forms.TextBox textBoxCStreetAddressLine2;
        private System.Windows.Forms.Label labelCRegion;
        private System.Windows.Forms.TextBox textBoxCCity;
        private System.Windows.Forms.TextBox textBoxCRegion;
        private System.Windows.Forms.Label labelCCity;
        private System.Windows.Forms.Label labelCState;
        private System.Windows.Forms.ComboBox comboBoxCState;
        private System.Windows.Forms.Label labelPreferredPaymentMethod;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label labelExpiryDateYear;
        private System.Windows.Forms.Label labelExpiryDateMonth;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label labelNameOnCreditCard;
        private System.Windows.Forms.Label labelCreditCardType;
        private System.Windows.Forms.Label labelCreditCardNumber;
        private System.Windows.Forms.Label labelExistingOrders;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button buttonOpenOrder;
        private System.Windows.Forms.DataGridView dataGridViewOrders;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label labelCustomerId;
        private System.Windows.Forms.Label labelCustomerNameValue;
        private System.Windows.Forms.Label labelCustomerIdValue;
        private com.icarustravel.enterprise31.Customer.CustomerDS customerDSCustomerData;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oRDERDATEDataGridViewTextBoxColumn;
    }
}
