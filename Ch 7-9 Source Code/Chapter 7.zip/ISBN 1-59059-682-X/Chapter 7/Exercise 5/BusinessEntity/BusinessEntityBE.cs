using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Configuration;

namespace com.icarustravel.enterprise31.BusinessEntity
{
    public abstract class BusinessEntityBE<LocalDSType, RemoteDSType> : DualPersistBE
        where LocalDSType : DataSet, new()
        where RemoteDSType : DataSet, new()
    {
        protected LocalDSType data;
        protected static string wSURL = null;

        public LocalDSType Data
        {
            get { return this.data; }
            set { this.data = value; }
        }

        static BusinessEntityBE()
        {
            if (InstalledMode == InstallMode.CLIENT)
            {
                Configuration exeConfiguration =
                  ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                if (exeConfiguration != null)
                {
                    ConfigurationSectionGroup settingsSectionGroup =
                      exeConfiguration.SectionGroups["applicationSettings"];
                    if (settingsSectionGroup != null)
                    {
                        ConfigurationSection settingsSection = settingsSectionGroup.Sections[
                          "com.icarustravel.enterprise31.BusinessEntity.Properties.Settings"];

                        if (settingsSection != null)
                        {
                            SettingElement settingElement =
                              ((System.Configuration.ClientSettingsSection)
                              (settingsSection)).Settings.Get(
                                                                "BusinessEntityBE_SalesWS_SalesWebService");

                            if (settingElement != null)
                            {
                                wSURL = settingElement.Value.ValueXml.InnerText;
                            }
                        }
                    }
                }
            }
        }


        protected void Fill(int id)
        {
            data = new LocalDSType();

            if (InstalledMode == InstallMode.CLIENT)
            {
                data.Merge(GetRemoteData(id));
            }
            else
            {
                GetLocalData(id);
            }
        }

        protected virtual RemoteDSType GetRemoteData(int id)
        {
            return new RemoteDSType();
        }

        protected virtual void GetLocalData(int id)
        {
        }
    }
}

