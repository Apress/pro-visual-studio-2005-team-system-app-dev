using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace com.icarustravel.enterprise31.Order
{
    public class OrderBE
    {
        OrderDS data;

        public OrderDS Data
        {
            get { return data; }
            set { data = value; }
        }

        public static OrderBE Get(int id)
        {
            OrderBE orderBE = new OrderBE();
            orderBE.data = new OrderDS();

            orderBE.Data.ORDER.LoadDataRow(new object[] { 1, 2, DateTime.Now }, true);

            orderBE.Data.RESERVATION.LoadDataRow(new object[] { 1, 1, 1, 1, 1, "Vendor 1", "Description 1", DateTime.Now, 1, 35.0, 35.0 }, true);
            orderBE.Data.RESERVATION.LoadDataRow(new object[] { 2, 2, 2, 2, 1, "Vendor 2", "Description 1", DateTime.Now, 1, 35.0, 35.0 }, true);
            orderBE.Data.RESERVATION.LoadDataRow(new object[] { 3, 3, 3, 3, 1, "Vendor 3", "Description 1", DateTime.Now, 1, 35.0, 35.0 }, true);
            orderBE.Data.RESERVATION.LoadDataRow(new object[] { 4, 4, 4, 4, 1, "Vendor 4", "Description 1", DateTime.Now, 1, 35.0, 35.0 }, true);

            return orderBE;
        }

        public void Delete(int id)
        {
        }

        public DataTable GetDataTable(int id, string tableName)
        {
            return Get(id).Data.Tables[tableName];
        }

        public void Save()
        {
        }
    }
}
