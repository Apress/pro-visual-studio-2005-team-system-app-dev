using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace com.icarustravel.enterprise31.BusinessEntity
{
    public abstract class BusinessEntityBE
    {
        public enum InstallMode
        {
            SERVER = 0,
            CLIENT = 1
        }

        private static InstallMode installedMode = InstallMode.SERVER;

        public static InstallMode InstalledMode
        {
            get { return installedMode; }
            set { installedMode = value; }
        }

        protected DataSet data;
    }
}
