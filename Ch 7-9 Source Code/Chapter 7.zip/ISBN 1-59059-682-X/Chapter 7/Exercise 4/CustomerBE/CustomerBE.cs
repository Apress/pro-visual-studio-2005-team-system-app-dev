using System;
using System.Collections.Generic;
using System.Text;

using com.icarustravel.enterprise31.BusinessEntity;
using com.icarustravel.enterprise31.Customer.CustomerDSTableAdapters;

namespace com.icarustravel.enterprise31.Customer
{
    class CustomerBE : BusinessEntityBE
    {
        protected void Fill(int id)
        {
            if (InstalledMode == InstallMode.CLIENT)
            {
                SalesWS.SalesWebService salesWebService =
                                    new SalesWS.SalesWebService();
                data = new CustomerDS();
                data.Merge(salesWebService.GetCustomer(id));
            }
            else
            {
                CustomerDS customerDS = new CustomerDS();
                new COUNTRIESTableAdapter().Fill(customerDS.COUNTRIES);
                new STATESTableAdapter().Fill(customerDS.STATES);
                new ORDERTableAdapter().Fill(customerDS.ORDER, id);
                new CUSTOMERTableAdapter().Fill(customerDS.CUSTOMER, id);
                data = customerDS;
            }
        }

        public static CustomerBE Get(int id)
        {
            CustomerBE customerBE = new CustomerBE();

            customerBE.Fill(id);

            return customerBE;
        }
    }
}
