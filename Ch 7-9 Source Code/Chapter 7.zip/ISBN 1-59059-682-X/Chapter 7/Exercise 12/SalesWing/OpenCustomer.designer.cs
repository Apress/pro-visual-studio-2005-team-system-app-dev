namespace com.icarustravel.enterprise31.SalesWing
{
    partial class OpenCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCustomerId = new System.Windows.Forms.Label();
            this.labelFamilyName = new System.Windows.Forms.Label();
            this.labelGivenName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxCustomerId = new System.Windows.Forms.TextBox();
            this.textBoxFamilyName = new System.Windows.Forms.TextBox();
            this.textBoxGivenName = new System.Windows.Forms.TextBox();
            this.dataGridViewCustomerSearchResults = new System.Windows.Forms.DataGridView();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.customerSearchDSSearchData = new com.icarustravel.enterprise31.Customer.CustomerSearchDS();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fAMILYNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gIVENNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomerSearchResults)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerSearchDSSearchData)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCustomerId
            // 
            this.labelCustomerId.AutoSize = true;
            this.labelCustomerId.Location = new System.Drawing.Point(26, 44);
            this.labelCustomerId.Name = "labelCustomerId";
            this.labelCustomerId.Size = new System.Drawing.Size(65, 13);
            this.labelCustomerId.TabIndex = 0;
            this.labelCustomerId.Text = "Customer ID";
            // 
            // labelFamilyName
            // 
            this.labelFamilyName.AutoSize = true;
            this.labelFamilyName.Location = new System.Drawing.Point(149, 44);
            this.labelFamilyName.Name = "labelFamilyName";
            this.labelFamilyName.Size = new System.Drawing.Size(67, 13);
            this.labelFamilyName.TabIndex = 1;
            this.labelFamilyName.Text = "Family Name";
            // 
            // labelGivenName
            // 
            this.labelGivenName.AutoSize = true;
            this.labelGivenName.Location = new System.Drawing.Point(329, 44);
            this.labelGivenName.Name = "labelGivenName";
            this.labelGivenName.Size = new System.Drawing.Size(66, 13);
            this.labelGivenName.TabIndex = 2;
            this.labelGivenName.Text = "Given Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Customer Details";
            // 
            // textBoxCustomerId
            // 
            this.textBoxCustomerId.Location = new System.Drawing.Point(59, 75);
            this.textBoxCustomerId.Name = "textBoxCustomerId";
            this.textBoxCustomerId.Size = new System.Drawing.Size(87, 20);
            this.textBoxCustomerId.TabIndex = 4;
            this.textBoxCustomerId.TextChanged += new System.EventHandler(this.textBoxCustomerId_TextChanged);
            // 
            // textBoxFamilyName
            // 
            this.textBoxFamilyName.Location = new System.Drawing.Point(152, 75);
            this.textBoxFamilyName.Name = "textBoxFamilyName";
            this.textBoxFamilyName.Size = new System.Drawing.Size(174, 20);
            this.textBoxFamilyName.TabIndex = 5;
            this.textBoxFamilyName.TextChanged += new System.EventHandler(this.textBoxFamilyName_TextChanged);
            // 
            // textBoxGivenName
            // 
            this.textBoxGivenName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxGivenName.Location = new System.Drawing.Point(332, 75);
            this.textBoxGivenName.Name = "textBoxGivenName";
            this.textBoxGivenName.Size = new System.Drawing.Size(170, 20);
            this.textBoxGivenName.TabIndex = 6;
            this.textBoxGivenName.TextChanged += new System.EventHandler(this.textBoxGivenName_TextChanged);
            // 
            // dataGridViewCustomerSearchResults
            // 
            this.dataGridViewCustomerSearchResults.AllowUserToAddRows = false;
            this.dataGridViewCustomerSearchResults.AllowUserToDeleteRows = false;
            this.dataGridViewCustomerSearchResults.AllowUserToResizeColumns = false;
            this.dataGridViewCustomerSearchResults.AllowUserToResizeRows = false;
            this.dataGridViewCustomerSearchResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewCustomerSearchResults.AutoGenerateColumns = false;
            this.dataGridViewCustomerSearchResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustomerSearchResults.ColumnHeadersVisible = false;
            this.dataGridViewCustomerSearchResults.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.fAMILYNAMEDataGridViewTextBoxColumn,
            this.gIVENNAMEDataGridViewTextBoxColumn});
            this.dataGridViewCustomerSearchResults.DataMember = "CUSTOMERSEARCH";
            this.dataGridViewCustomerSearchResults.DataSource = this.customerSearchDSSearchData;
            this.dataGridViewCustomerSearchResults.Location = new System.Drawing.Point(29, 113);
            this.dataGridViewCustomerSearchResults.MultiSelect = false;
            this.dataGridViewCustomerSearchResults.Name = "dataGridViewCustomerSearchResults";
            this.dataGridViewCustomerSearchResults.ReadOnly = true;
            this.dataGridViewCustomerSearchResults.RowHeadersWidth = 30;
            this.dataGridViewCustomerSearchResults.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCustomerSearchResults.Size = new System.Drawing.Size(473, 299);
            this.dataGridViewCustomerSearchResults.TabIndex = 7;
            // 
            // buttonOpen
            // 
            this.buttonOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpen.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOpen.Location = new System.Drawing.Point(427, 433);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(75, 23);
            this.buttonOpen.TabIndex = 8;
            this.buttonOpen.Text = "Open";
            this.buttonOpen.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(332, 433);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 9;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // customerSearchDSSearchData
            // 
            this.customerSearchDSSearchData.DataSetName = "CustomerSearchDS";
            this.customerSearchDSSearchData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fAMILYNAMEDataGridViewTextBoxColumn
            // 
            this.fAMILYNAMEDataGridViewTextBoxColumn.DataPropertyName = "FAMILYNAME";
            this.fAMILYNAMEDataGridViewTextBoxColumn.HeaderText = "FAMILYNAME";
            this.fAMILYNAMEDataGridViewTextBoxColumn.Name = "fAMILYNAMEDataGridViewTextBoxColumn";
            this.fAMILYNAMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gIVENNAMEDataGridViewTextBoxColumn
            // 
            this.gIVENNAMEDataGridViewTextBoxColumn.DataPropertyName = "GIVENNAME";
            this.gIVENNAMEDataGridViewTextBoxColumn.HeaderText = "GIVENNAME";
            this.gIVENNAMEDataGridViewTextBoxColumn.Name = "gIVENNAMEDataGridViewTextBoxColumn";
            this.gIVENNAMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // OpenCustomer
            // 
            this.AcceptButton = this.buttonOpen;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(536, 468);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOpen);
            this.Controls.Add(this.dataGridViewCustomerSearchResults);
            this.Controls.Add(this.textBoxGivenName);
            this.Controls.Add(this.textBoxFamilyName);
            this.Controls.Add(this.textBoxCustomerId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelGivenName);
            this.Controls.Add(this.labelFamilyName);
            this.Controls.Add(this.labelCustomerId);
            this.Name = "OpenCustomer";
            this.Text = "Open Customer";
            this.Load += new System.EventHandler(this.OpenCustomer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomerSearchResults)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerSearchDSSearchData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCustomerId;
        private System.Windows.Forms.Label labelFamilyName;
        private System.Windows.Forms.Label labelGivenName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxCustomerId;
        private System.Windows.Forms.TextBox textBoxFamilyName;
        private System.Windows.Forms.TextBox textBoxGivenName;
        private System.Windows.Forms.DataGridView dataGridViewCustomerSearchResults;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.Button buttonCancel;
        private com.icarustravel.enterprise31.Customer.CustomerSearchDS customerSearchDSSearchData;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fAMILYNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gIVENNAMEDataGridViewTextBoxColumn;
    }
}