using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using com.icarustravel.enterprise31.Customer;

namespace com.icarustravel.enterprise31.SalesWing
{
    public partial class CustomerDetails : UserControl
    {
        public event CloseEventDelegate Close;
        public delegate void CloseEventDelegate(Control control);

        public CustomerDS Data
        {
            set { this.customerDSCustomerData = value; }
            get { return this.customerDSCustomerData; }
        }

        public string CustomerName
        {
            get
            {
                if (this.customerDSCustomerData.CUSTOMER.Rows.Count == 1)
                {
                    CustomerDS.CUSTOMERRow customerRow =
                        this.customerDSCustomerData.CUSTOMER[0];
                    return customerRow.FAMILYNAME + ", " + customerRow.GIVENNAME;
                }
                else
                    return "";
            }
        }

        public CustomerDetails()
        {
            InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Close.Invoke(this);
        }
    }
}
