using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using com.icarustravel.enterprise31.Customer;

namespace com.icarustravel.enterprise31.SalesWing
{
    public partial class OpenCustomer : Form
    {
        public OpenCustomer()
        {
            InitializeComponent();
        }

        public int SelectedId
        {
            get
            {
                return (int)dataGridViewCustomerSearchResults.SelectedRows[0].Cells["iDDataGridViewTextBoxColumn"].Value;
            }
        }

        private void OpenCustomer_Load(object sender, EventArgs e)
        {
            UpdateCustomerSearchData();
        }

        private void textBoxCustomerId_TextChanged(object sender, EventArgs e)
        {
            UpdateCustomerSearchData();
        }

        private void textBoxFamilyName_TextChanged(object sender, EventArgs e)
        {
            UpdateCustomerSearchData();
        }

        private void textBoxGivenName_TextChanged(object sender, EventArgs e)
        {
            UpdateCustomerSearchData();
        }

        private void UpdateCustomerSearchData()
        {
            this.customerSearchDSSearchData.Clear();
            this.customerSearchDSSearchData.Merge(CustomerSearchBE.Get(
                this.textBoxCustomerId.Text, this.textBoxFamilyName.Text, this.textBoxGivenName.Text).Data);
        }
    }
}