using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using com.icarustravel.enterprise31.Customer;

namespace com.icarustravel.enterprise31.SalesWing
{
    public partial class CustomerDetails : UserControl
    {
        public event CloseEventDelegate Close;
        public delegate void CloseEventDelegate(Control control);

        public CustomerDS Data
        {
            set { this.customerDSCustomerData = value; }
            get { return this.customerDSCustomerData; }
        }

        public CustomerDetails()
        {
            InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Close.Invoke(this);
        }
    }
}
