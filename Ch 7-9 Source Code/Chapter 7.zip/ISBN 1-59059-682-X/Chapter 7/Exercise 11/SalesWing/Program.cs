using System;
using System.Collections.Generic;
using System.Windows.Forms;

using com.icarustravel.enterprise31.BusinessEntity;

namespace com.icarustravel.enterprise31.SalesWing
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            DualPersistBE.InstalledMode = DualPersistBE.InstallMode.CLIENT; 
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CustomerContacts());
        }
    }
}